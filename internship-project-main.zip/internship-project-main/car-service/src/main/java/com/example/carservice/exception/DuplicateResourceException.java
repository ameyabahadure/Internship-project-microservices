package com.example.carservice.exception;

/**
 * Custom exception thrown when a duplicate resource is detected.
 * <p>
 * This exception extends {@link RuntimeException} and is used to indicate
 * that an attempt was made to create or persist a resource that already
 * exists in the system.
 * </p>
 *
 * <p>
 * Common scenarios include:
 * <ul>
 *     <li>Duplicate car registration number</li>
 *     <li>Repeated unique field values</li>
 * </ul>
 * </p>
 *
 * <p>
 * This exception can be handled globally to return appropriate HTTP
 * responses such as 409 Conflict.
 * </p>
 *
 * @author
 * @since 1.0
 */

public class DuplicateResourceException extends RuntimeException {

/**
     * Constructs a new {@code DuplicateResourceException} with the specified message.
     *
     * @param message the detail message explaining the cause of duplication
     */

    public DuplicateResourceException(String message) {
        super(message);
    }
}
