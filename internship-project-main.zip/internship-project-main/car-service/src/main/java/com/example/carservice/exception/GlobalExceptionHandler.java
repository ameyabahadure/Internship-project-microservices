package com.example.carservice.exception;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.carservice.dto.GenericResponse;

import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for managing application-wide exceptions
 * in the Car Service module.
 * <p>
 * This class centralizes exception handling and ensures consistent
 * error responses using {@link GenericResponse}.
 * </p>
 *
 * <p>
 * It handles:
 * <ul>
 *     <li>Resource not found exceptions</li>
 *     <li>Duplicate resource exceptions</li>
 *     <li>Validation errors</li>
 *     <li>Customer-related exceptions</li>
 *     <li>Invalid car exceptions</li>
 *     <li>Generic system exceptions</li>
 * </ul>
 * </p>
 *
 * <p>
 * All responses are standardized to provide meaningful messages
 * and HTTP status codes.
 * </p>
 *
 * @author
 * @since 1.0
 */

@RestControllerAdvice
public class GlobalExceptionHandler {
	
/**
     * Handles {@link ResourceNotFoundException}.
     *
     * @param ex the exception thrown when a resource is not found
     * @return response with HTTP 404 status and error message
     */

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<GenericResponse<?>> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(404)
                .body(new GenericResponse<>(ex.getMessage()));
    }


/**
     * Handles {@link DuplicateResourceException}.
     *
     * @param ex the exception thrown for duplicate resource creation
     * @return response with HTTP 400 status and error message
     */


    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<GenericResponse<?>> handleDuplicate(DuplicateResourceException ex) {
        return ResponseEntity.status(400)
                .body(new GenericResponse<>(ex.getMessage()));
    }

/**
     * Handles validation exceptions triggered by invalid method arguments.
     * <p>
     * Extracts field-level validation errors and returns them as a map.
     * </p>
     *
     * @param ex the validation exception
     * @return response with HTTP 400 status containing validation errors
     */

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<GenericResponse<Map<String, String>>> handleValidation(MethodArgumentNotValidException ex) {

        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult().getFieldErrors().forEach(err ->
                errors.put(err.getField(), err.getDefaultMessage())
        );

        return ResponseEntity.status(400)
                .body(new GenericResponse<>("Validation failed", errors));
    }

/**
     * Handles {@link CustomerNotFoundException}.
     *
     * @param ex the exception thrown when a customer is not found
     * @return response with HTTP 404 status and error message
     */


    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<GenericResponse<?>> handleCustomerNotFound(CustomerNotFoundException ex) {
        return ResponseEntity.status(404)
                .body(new GenericResponse<>(ex.getMessage()));
    }

/**
     * Handles {@link InvalidCarException}.
     *
     * @param ex the exception thrown when a car is invalid
     * @return response with HTTP 400 status and error message
     */

    @ExceptionHandler(InvalidCarException.class)
    public ResponseEntity<GenericResponse<?>> handleInvalidCar(InvalidCarException ex) {
        return ResponseEntity.status(400)
                .body(new GenericResponse<>(ex.getMessage()));
    }

/**
     * Handles all other unhandled exceptions.
     *
     * @param ex the generic exception
     * @return response with HTTP 500 status and error message
     */

    @ExceptionHandler(Exception.class)
    public ResponseEntity<GenericResponse<?>> handleGeneric(Exception ex) {
        return ResponseEntity.status(500)
                .body(new GenericResponse<>(ex.getMessage()));
    }
}
