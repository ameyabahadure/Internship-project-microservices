package com.example.carservice.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.carservice.model.CarService;
import com.example.carservice.service.CarServiceService;

/**
 * REST controller responsible for handling car service-related operations.
 * <p>
 * This controller exposes endpoints for performing CRUD operations on
 * {@link CarService} entities. It acts as an interface between client requests
 * and the service layer.
 * </p>
 *
 * <p><b>Base Path:</b> /carservice</p>
 *
 * @author 
 * @since 1.0
 */

@RestController
@RequestMapping("/carservice")
public class CarServiceController {

	/**
     * Service dependency used to perform business logic operations
     * related to {@link CarService}.
     */

    private final CarServiceService carServiceService;

    // ✅ Replaced loose field @Autowired with explicit constructor injection

     /**
      * Constructs a new {@code CarServiceController} with the specified service.
      *
      * @param carServiceService the service instance used to manage car service operations
      */

    // ✅ Replaced loose field @Autowired with explicit constructor injection
    public CarServiceController(CarServiceService carServiceService) {
        this.carServiceService = carServiceService;
    }
    

    /**
     * Retrieves all car service records.
     *
     * @return a {@link ResponseEntity} containing a list of {@link CarService}
     *         objects with HTTP status OK
     */
    @GetMapping
    public ResponseEntity<List<CarService>> getAll() {
        return ResponseEntity.ok(carServiceService.getAll());
    }

    /**
     * Creates and saves a new car service record.
     *
     * @param carService the {@link CarService} object to be persisted
     * @return a {@link ResponseEntity} containing the saved {@link CarService}
     *         with HTTP status CREATED
     */
    @PostMapping("/save")
    public ResponseEntity<CarService> save(@RequestBody CarService carService) {
        return new ResponseEntity<>(carServiceService.save(carService), HttpStatus.CREATED);
    }
	

    /**
     * Retrieves a specific car service record by its unique identifier.
     *
     * @param id the unique identifier of the car service
     * @return a {@link ResponseEntity} containing the requested {@link CarService}
     *         with HTTP status OK
     */    
    @GetMapping("/{id}") 
    public ResponseEntity<CarService> getService(@PathVariable Long id) {
        return ResponseEntity.ok(carServiceService.getById(id));
    }

    /**
     * Deletes a car service record based on the given identifier.
     *
     * @param id the unique identifier of the car service to be deleted
     * @return a {@link ResponseEntity} containing a confirmation message
     *         with HTTP status ACCEPTED
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteService(@PathVariable Long id) {
        carServiceService.deleteById(id);
        return new ResponseEntity<>("Deletion successful", HttpStatus.ACCEPTED);
    }

    /**
     * Updates an existing car service record identified by the given ID.
     *
     * @param id the unique identifier of the car service to update
     * @param updatedCarService the updated {@link CarService} object
     * @return a {@link ResponseEntity} containing the updated {@link CarService}
     *         with HTTP status OK
     */

    @PutMapping("/{id}")
    public ResponseEntity<CarService> updateById(@PathVariable Long id, @RequestBody CarService updatedCarService) {
        return new ResponseEntity<>(carServiceService.updateById(id, updatedCarService), HttpStatus.OK);
    }
}