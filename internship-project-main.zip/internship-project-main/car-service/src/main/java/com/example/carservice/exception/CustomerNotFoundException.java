package com.example.carservice.exception;
/**
 * Custom exception thrown when a customer resource is not found.
 * <p>
 * This exception extends {@link RuntimeException} and is used to indicate
 * that a requested customer entity does not exist in the system.
 * </p>
 *
 * <p>
 * Typically used in service or controller layers when performing
 * operations that require a valid customer reference.
 * </p>
 *
 * <p>
 * This exception can be handled by a global exception handler to return
 * an appropriate HTTP response (e.g., 404 Not Found).
 * </p>
 *
 * @author
 * @since 1.0
 */
public class CustomerNotFoundException extends RuntimeException {

/**
     * Constructs a new {@code CustomerNotFoundException} with the specified message.
     *
     * @param message the detail message explaining why the exception occurred
     */

    public CustomerNotFoundException(String message) {
        super(message);
    }
}
