package com.example.carservice.feign;

import feign.RequestInterceptor;

import feign.RequestTemplate;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;

/**
 * Feign client interceptor for propagating Authorization headers
 * across service-to-service communication.
 * <p>
 * This interceptor extracts the Authorization header (typically containing
 * a JWT token) from the incoming HTTP request and attaches it to outgoing
 * Feign requests.
 * </p>
 *
 * <p>
 * This ensures that authentication and authorization contexts are preserved
 * when one microservice invokes another.
 * </p>
 *
 * <p>
 * Commonly used in secured microservice architectures to maintain
 * identity propagation.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Configuration
public class FeignClientInterceptor implements RequestInterceptor {

/**
     * HTTP servlet request used to retrieve incoming request headers.
     */
 
    @Autowired
    private HttpServletRequest request;

/**
     * Applies the interceptor logic to outgoing Feign requests.
     * <p>
     * Extracts the "Authorization" header from the incoming request and
     * sets it in the Feign request template if present.
     * </p>
     *
     * @param template the Feign request template to modify
     */
 
    @Override
    public void apply(RequestTemplate template) {
 
        String token = request.getHeader("Authorization");
 
        if (token != null) {

            template.header("Authorization", token);

        }

    }

}