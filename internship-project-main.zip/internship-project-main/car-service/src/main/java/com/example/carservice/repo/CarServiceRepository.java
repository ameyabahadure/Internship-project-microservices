package com.example.carservice.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.carservice.model.CarService;

/**
 * Repository interface for performing CRUD operations on
 * {@link CarService} entities.
 * <p>
 * Extends {@link JpaRepository} to provide standard database operations
 * such as save, delete, update, and find.
 * </p>
 *
 * <p>
 * Additional query methods are defined for retrieving and validating
 * car service records using the car registration number.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface CarServiceRepository extends JpaRepository<CarService,Long>{
	

	/**
     * Retrieves a car service record based on the car registration number.
     *
     * @param carRegistrationNumber the registration number of the car
     * @return an {@link Optional} containing the {@link CarService} if found,
     *         otherwise empty
     */

    Optional<CarService> findByCarRegistrationNumber(String carRegistrationNumber);
    

    /**
     * Checks whether a car service record exists for the given
     * car registration number.
     *
     * @param carRegistrationNumber the registration number of the car
     * @return {@code true} if a record exists, otherwise {@code false}
     */

    boolean existsByCarRegistrationNumber(String carRegistrationNumber);
}
