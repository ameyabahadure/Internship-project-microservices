
package com.example.carservice.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client interface for interacting with the
 * Car Validation Service.
 * <p>
 * This client is responsible for validating car registration numbers
 * by making REST calls to the external "car-validation-service".
 * </p>
 *
 * <p>
 * Uses Spring Cloud OpenFeign to simplify HTTP communication
 * between microservices.
 * </p>
 *
 * @author
 * @since 1.0
 */
@FeignClient(name = "car-validation-service")//provide the application-name of the validation service
public interface ValidationClient {

    /**
     * Validates the given car registration number.
     *
     * @param carNumber the car registration number to validate
     * @return {@code true} if the car number is valid, {@code false} otherwise
     */
    @GetMapping("/validate/{carNumber}") //make sure the path is same as used in Validation project controller
    Boolean validateCar(@PathVariable("carNumber") String carNumber);
    
}
