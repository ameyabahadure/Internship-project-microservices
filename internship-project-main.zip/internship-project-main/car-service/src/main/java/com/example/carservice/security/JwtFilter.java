package com.example.carservice.security;

import jakarta.servlet.FilterChain;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;
 
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

import io.jsonwebtoken.Claims;

import io.jsonwebtoken.Jwts;

import io.jsonwebtoken.security.Keys;
 
 
import javax.crypto.SecretKey;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
 
@Component

public class JwtFilter extends OncePerRequestFilter {

    private final String SECRET = "X9aB7cQmP4tR2vL8wZ6yN0kD3fH5jG1uE7oS4nM2bV9rT8qC5xJ";
 
//    FOR H2 CONSOLE

    @Override

    protected boolean shouldNotFilter(HttpServletRequest request) {

        String path = request.getRequestURI();

        return path.startsWith("/h2-console") || path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs");

    }

 
    @Override

    protected void doFilterInternal(HttpServletRequest request,

                                   HttpServletResponse response,

                                   FilterChain filterChain)

            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        //No token case

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().write("JWT token is missing");

            return;

        }

        String token = authHeader.substring(7);

        try {

            SecretKey key = Keys.hmacShaKeyFor(SECRET.getBytes());

            // Parse token

            Claims claims = Jwts.parserBuilder()

                    .setSigningKey(key)

                    .build()

                    .parseClaimsJws(token)

                    .getBody();

            //  Check expiry

            if (claims.getExpiration().before(new Date())) {

                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

                response.getWriter().write("JWT expired");

                return;

            }
            
            String username = claims.getSubject();
            

         //  Extract ROLES from JWT
            String roles = claims.get("role", String.class);

  List<SimpleGrantedAuthority> authorities = Arrays.stream(roles.split(","))
                             .map(String::trim)
                             .map(SimpleGrantedAuthority::new) // expects ROLE_ADMIN, ROLE_USER
                             .collect(Collectors.toList());



  		   // Create authentication WITH ROLES
           UsernamePasswordAuthenticationToken authentication =
                   new UsernamePasswordAuthenticationToken(
                           username,
                           null,
                           authorities
                   );


            SecurityContextHolder.getContext().setAuthentication(authentication);

        } catch (Exception e) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().write("Invalid JWT token");

            return;

        }

        filterChain.doFilter(request, response);

    }

}