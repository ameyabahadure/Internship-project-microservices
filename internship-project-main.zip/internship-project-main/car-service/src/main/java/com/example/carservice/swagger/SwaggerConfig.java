package com.example.carservice.swagger;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.security.SecurityScheme;
 
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

 /**
 * Configuration class for setting up OpenAPI (Swagger) documentation.
 * <p>
 * This class defines the API documentation metadata and security configuration
 * for the application using SpringDoc OpenAPI.
 * </p>
 *
 * <p>
 * It configures:
 * <ul>
 *     <li>API title and version</li>
 *     <li>JWT-based authentication using Bearer token</li>
 *     <li>Security scheme for protected endpoints</li>
 * </ul>
 * </p>
 *
 * @author
 * @since 1.0
 */

@Configuration
public class SwaggerConfig {

	/**
     * Creates and configures the OpenAPI bean for API documentation.
     * <p>
     * This configuration includes:
     * <ul>
     *     <li>Security requirement using bearer authentication</li>
     *     <li>Definition of JWT security scheme</li>
     *     <li>Basic API metadata (title and version)</li>
     * </ul>
     *
     * @return the configured {@link OpenAPI} instance
     */

	@Bean
	public OpenAPI customOpenAPI() {
		return new OpenAPI().addSecurityItem(new SecurityRequirement().addList("bearerAuth"))
				.components(new Components().addSecuritySchemes("bearerAuth",
						new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
				.info(new Info().title("Car Service API").version("1.0"));
	}
 
}
