package com.example.carservice.enums;

/**
 * Enumeration representing the different types of car services.
 * <p>
 * This enum defines the categories of services that can be performed
 * on a vehicle within the system.
 * </p>
 *
 * <ul>
 *     <li>{@link #OIL_CHANGE} - Engine oil replacement service</li>
 *     <li>{@link #GENERAL_SERVICE} - Routine maintenance and servicing</li>
 *     <li>{@link #REPAIR} - Fixing mechanical or electrical issues</li>
 *     <li>{@link #WASH} - Vehicle cleaning and washing service</li>
 *     <li>{@link #INSPECTION} - Vehicle inspection for diagnostics or compliance</li>
 * </ul>
 *
 * @author
 * @since 1.0
 */
public enum ServiceType {

    /**
     * Represents an oil change service for the vehicle.
     */
    OIL_CHANGE,

    /**
     * Represents a general maintenance service.
     */
    GENERAL_SERVICE,

    /**
     * Represents repair work for faults or damages.
     */
    REPAIR,

    /**
     * Represents a vehicle washing service.
     */
    WASH,

    /**
     * Represents an inspection service for diagnostics or verification.
     */
    INSPECTION
}