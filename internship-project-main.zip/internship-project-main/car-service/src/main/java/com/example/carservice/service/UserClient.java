package com.example.carservice.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.carservice.dto.UserProfileDTO;

/**
 * Feign client interface for communicating with the
 * User Profile Service.
 * <p>
 * This client provides methods to fetch user-related data
 * from the external "user-profile-service" microservice.
 * </p>
 *
 * <p>
 * Uses Spring Cloud OpenFeign to simplify REST API communication.
 * </p>
 *
 * @author
 * @since 1.0
 */
@FeignClient(name = "user-profile-service")
public interface UserClient {

    /**
     * Retrieves user profile information based on the username.
     *
     * @param username the username of the user
     * @return the {@link UserProfileDTO} containing user details
     */
    @GetMapping("/users/{username}")
    UserProfileDTO getUser(@PathVariable("username") String username);
}