package com.example.carservice.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.antlr.v4.runtime.misc.NotNull;

import com.example.carservice.enums.ServiceStatus;
import com.example.carservice.enums.ServiceType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

/**
 * Entity class representing a car service record in the system.
 * <p>
 * This class maps to a database table storing information about
 * vehicle service details such as service type, status, customer,
 * and timestamps.
 * </p>
 *
 * <p>
 * It uses JPA annotations for ORM mapping and lifecycle callbacks
 * to automatically manage creation and update timestamps.
 * </p>
 *
 * @author
 * @since 1.0
 */
@Entity
@Table(name = "car_service")
public class CarService {

    /**
     * Unique identifier for the car service record.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Registration number of the car.
     */
    @NotNull
    @Column(name = "car_registration_number", nullable = false, unique = true, length = 20)
    private String carRegistrationNumber;

    /**
     * Identifier of the customer associated with the service.
     */
    @NotNull
    @Column(name = "customer_id", nullable = false)
    private Long customerId; //FK 

    /**
     * Type of service performed on the car.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "service_type", nullable = false, length = 50)
    private ServiceType serviceType;
    
    /**
     * Current status of the car service.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "service_status", nullable = false, length = 50)
    private ServiceStatus serviceStatus;

    /**
     * Date on which the service is scheduled or performed.
     */
    @NotNull
    @Column(name = "service_date", nullable = false)
    private LocalDate serviceDate;
    
    /**
     * Additional notes or remarks about the service.
     */
    @Column(name = "notes", length = 250)
    private String notes;

    /**
     * Timestamp indicating when the record was created.
     * This field is not updatable.
     */
    @NotNull
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Timestamp indicating when the record was last updated.
     */
    @NotNull
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /**
     * Lifecycle callback method triggered before persisting the entity.
     * Initializes the creation and update timestamps.
     */
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Lifecycle callback method triggered before updating the entity.
     * Updates the last modified timestamp.
     */
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * Default constructor for JPA.
     */
    public CarService() {
        
    }
    
    /**
     * Parameterized constructor to initialize all fields.
     *
     * @param id the unique identifier
     * @param carRegistrationNumber the car registration number
     * @param customerId the customer identifier
     * @param serviceType the type of service
     * @param serviceDate the service date
     * @param serviceStatus the status of the service
     * @param notes additional notes
     * @param createdAt record creation timestamp
     * @param updatedAt record last update timestamp
     */
    public CarService(Long id, String carRegistrationNumber, Long customerId, ServiceType serviceType, LocalDate serviceDate,
            ServiceStatus serviceStatus, String notes, LocalDateTime createdAt, LocalDateTime updatedAt) {
        super();
        this.id = id;
        this.carRegistrationNumber = carRegistrationNumber;
        this.customerId = customerId;
        this.serviceType = serviceType;
        this.serviceDate = serviceDate;
        this.serviceStatus = serviceStatus;
        this.notes = notes;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    /**
     * Returns a string representation of the car service object.
     *
     * @return string containing all field values
     */
    @Override
    public String toString() {
        return "CarService [id=" + id + ", carRegistrationNumber=" + carRegistrationNumber + ", customerId="
                + customerId + ", serviceType=" + serviceType + ", serviceDate=" + serviceDate + ", serviceStatus="
                + serviceStatus + ", notes=" + notes + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + "]";
    }

    /**
     * Gets the service ID.
     *
     * @return the ID
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the service ID.
     *
     * @param id the ID to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the car registration number.
     *
     * @return the car registration number
     */
    public String getCarRegistrationNumber() {
        return carRegistrationNumber;
    }

    /**
     * Sets the car registration number.
     *
     * @param carRegistrationNumber the registration number to set
     */
    public void setCarRegistrationNumber(String carRegistrationNumber) {
        this.carRegistrationNumber = carRegistrationNumber;
    }

    /**
     * Gets the customer ID.
     *
     * @return the customer ID
     */
    public Long getCustomerId() {
        return customerId;
    }

    /**
     * Sets the customer ID.
     *
     * @param customerId the customer ID to set
     */
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    /**
     * Gets the service type.
     *
     * @return the service type
     */
    public ServiceType getServiceType() {
        return serviceType;
    }
    
    /**
     * Sets the service type.
     *
     * @param serviceType the service type to set
     */
    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    /**
     * Gets the service date.
     *
     * @return the service date
     */
    public LocalDate getServiceDate() {
        return serviceDate;
    }

    /**
     * Sets the service date.
     *
     * @param serviceDate the service date to set
     */
    public void setServiceDate(LocalDate serviceDate) {
        this.serviceDate = serviceDate;
    }

    /**
     * Gets the service status.
     *
     * @return the service status
     */
    public ServiceStatus getServiceStatus() {
        return serviceStatus;
    }
    
    /**
     * Sets the service status.
     *
     * @param serviceStatus the service status to set
     */
    public void setServiceStatus(ServiceStatus serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    /**
     * Gets additional notes.
     *
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Sets additional notes.
     *
     * @param notes the notes to set
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

    /**
     * Gets the creation timestamp.
     *
     * @return the creation timestamp
     */
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the creation timestamp.
     *
     * @param createdAt the timestamp to set
     */
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Gets the last updated timestamp.
     *
     * @return the updated timestamp
     */
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the last updated timestamp.
     *
     * @param updatedAt the timestamp to set
     */
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
