package com.example.carservice.dto;

public class AuditLogDTO {

    private Long carServiceId;
    private String action;
    private String performedBy;
    private String details;

    public AuditLogDTO() {
    }

    public AuditLogDTO(Long carServiceId, String action, String performedBy, String details) {
        this.carServiceId = carServiceId;
        this.action = action;
        this.performedBy = performedBy;
        this.details = details;
    }

    public Long getCarServiceId() {
        return carServiceId;
    }

    public void setCarServiceId(Long carServiceId) {
        this.carServiceId = carServiceId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}