package com.example.carservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.kafka.annotation.EnableKafka;

/**
 * The CarServiceApplication class is the main entry point for the Spring Boot application.
 * <p>
 * It enables the following features:
 * <ul>
 *     <li>Spring Boot auto-configuration using {@link SpringBootApplication}</li>
 *     <li>Feign clients for REST communication using {@link EnableFeignClients}</li>
 *     <li>Kafka support for messaging using {@link EnableKafka}</li>
 * </ul>
 * </p>
 *
 * @author
 */
@SpringBootApplication
@EnableFeignClients
@EnableKafka
public class CarServiceApplication {

    /**
     * The main method which serves as the entry point of the Spring Boot application.
     *
     * @param args command-line arguments passed during application startup
     */
    public static void main(String[] args) {
        SpringApplication.run(CarServiceApplication.class, args);
    }

}