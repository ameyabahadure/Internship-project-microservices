package com.example.carservice.enums;
/**
* Enumeration representing the status of a car service.
 * <p>
 * This enum defines the possible lifecycle states that a car service
 * can have within the system.
 * </p>
 *
 * <ul>
 *     <li>{@link #PENDING} - Service request has been created but not yet started</li>
 *     <li>{@link #IN_PROGRESS} - Service is currently being performed</li>
 *     <li>{@link #COMPLETED} - Service has been successfully completed</li>
 *     <li>{@link #CANCELLED} - Service has been cancelled before completion</li>
 * </ul>
 *
 * @author
 * @since 1.0
 */

public enum ServiceStatus {

/**
     * Indicates that the service request is pending and has not started yet.
     */
    PENDING,

    /**
     * Indicates that the service is currently in progress.
     */
    IN_PROGRESS,

    /**
     * Indicates that the service has been completed successfully.
     */
    COMPLETED,

    /**
     * Indicates that the service has been cancelled.
     */
    CANCELLED

}
