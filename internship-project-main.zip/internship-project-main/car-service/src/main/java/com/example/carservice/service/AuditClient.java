package com.example.carservice.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.carservice.dto.AuditLogDTO;


/**
 * Feign client interface for interacting with the external
 * Car Audit Service.
 * <p>
 * This client enables communication with the "car-audit-service"
 * microservice to record audit logs for various actions performed
 * within the system.
 * </p>
 *
 * <p>
 * Uses Spring Cloud OpenFeign to simplify REST API calls.
 * </p>
 *
 * @author
 * @since 1.0
 */

@FeignClient(name="car-audit-service")
public interface AuditClient {
	

	/**
     * Sends an audit log entry to the audit service.
     *
     * @param log the {@link AuditLogDTO} containing audit details
     * @return the response {@link AuditLogDTO} after being processed
     *         by the audit service
     */

    @PostMapping("/audit/log")
    AuditLogDTO logAction(AuditLogDTO log);
}