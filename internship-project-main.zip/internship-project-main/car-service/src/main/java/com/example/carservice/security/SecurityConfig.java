package com.example.carservice.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            //  Disable CSRF
            .csrf(csrf -> csrf.disable())

            //  Enable CORS
            .cors(cors -> {})

            //  Allow H2 console iframe
            .headers(headers -> headers
                .frameOptions(frame -> frame.disable())
            )

            .authorizeHttpRequests(auth -> auth

                //  PUBLIC (Swagger + H2)
                .requestMatchers("/h2-console/**").permitAll()
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()

                //  GET -> ADMIN + USER
                .requestMatchers(HttpMethod.GET, "/carservice/**")
                    .hasAnyRole("ADMIN", "USER")

                //  POST -> ADMIN ONLY 
                .requestMatchers(HttpMethod.POST, "/carservice/**")
                    .hasRole("ADMIN")

                //  PUT -> ADMIN ONLY
                .requestMatchers(HttpMethod.PUT, "/carservice/**")
                    .hasRole("ADMIN")

                //  DELETE -> ADMIN ONLY
                .requestMatchers(HttpMethod.DELETE, "/carservice/**")
                    .hasRole("ADMIN")

                //  Any other request must be authenticated
                .anyRequest().authenticated()
            )

            //  Stateless session (JWT)
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            );

        //  Add JWT Filter
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    //  CORS CONFIGURATION
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration config = new CorsConfiguration();

        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*");   // dev only
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");

        config.addExposedHeader("Authorization");

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);

        return source;
    }
}