package com.example.carservice.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

 /**
 * Utility class for retrieving security-related information
 * from the current Spring Security context.
 * <p>
 * This class provides helper methods to extract authentication
 * details such as the currently logged-in user's username from
 * the security context.
 * </p>
 *
 * <p>
 * Typically used in applications secured with JWT or other
 * authentication mechanisms integrated with Spring Security.
 * </p>
 *
 * @author
 * @since 1.0
 */

public class SecurityUtils {

	/**
     * Retrieves the username of the currently authenticated user.
     * <p>
     * If authentication is available and the user is authenticated,
     * the username is extracted from the {@link Authentication} object.
     * Otherwise, a default value of "UNKNOWN" is returned.
     * </p>
     *
     * @return the username of the authenticated user, or "UNKNOWN" if not authenticated
     */

    public static String getCurrentUsername() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.isAuthenticated()) {
            return authentication.getName(); // username from JWT
        }

        return "UNKNOWN";
    }
}