package com.example.carservice.producer;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Qualifier;

import com.example.carservice.dto.AuditLogDTO;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka producer service responsible for sending car service audit events
 * to a Kafka topic.
 * <p>
 * This class configures a Kafka producer and publishes audit log messages
 * asynchronously to the configured topic.
 * </p>
 *
 * <p>
 * It ensures:
 * <ul>
 *     <li>Custom Kafka template configuration</li>
 *     <li>JSON serialization of messages</li>
 *     <li>Decoupling of event publishing from business logic</li>
 * </ul>
 * </p>
 *
 * <p>
 * Used in event-driven architecture to communicate with the Audit Service.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Service
public class CarServiceProducer {

/**
     * Kafka topic where car audit events are published.
     */

    private static final String TOPIC = "car-audit-topic";

/**
     * KafkaTemplate used for sending messages to Kafka.
     */

    private final KafkaTemplate<String, Object> kafkaTemplate;

/**
     * Constructs a {@code CarServiceProducer} with the specified KafkaTemplate.
     *
     * @param kafkaTemplate the Kafka template bean used to send events
     */

    // ✅ Explicitly inject your custom template bean using @Qualifier
    public CarServiceProducer(@Qualifier("localKafkaTemplate") KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

/**
     * Creates a custom {@link KafkaTemplate} bean for local Kafka configuration.
     * <p>
     * Configures:
     * <ul>
     *     <li>Kafka broker address</li>
     *     <li>Key and value serializers</li>
     *     <li>JSON serialization without type headers</li>
     * </ul>
     * </p>
     *
     * @return configured {@link KafkaTemplate} instance
     */

    @Bean(name = "localKafkaTemplate")
    public static KafkaTemplate<String, Object> localKafkaTemplate() {
        Map<String, Object> configProps = new HashMap<>();

        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        // ✅ Prevents package mismatch crash on the receiving end
        configProps.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, false);

        ProducerFactory<String, Object> factory = new DefaultKafkaProducerFactory<>(configProps);
        return new KafkaTemplate<>(factory);
    }

/**
     * Sends a car service audit event to the Kafka topic.
     * <p>
     * This method:
     * <ul>
     *     <li>Publishes the given {@link AuditLogDTO} to Kafka</li>
     *     <li>Logs success or failure messages</li>
     * </ul>
     * </p>
     *
     * @param log the {@link AuditLogDTO} containing audit event details
     */

    public void sendCarEvent(AuditLogDTO log) {
        try {
            kafkaTemplate.send(TOPIC, log);
            System.out.println("🚀 Event sent to Kafka topic [" + TOPIC + "] for CarServiceId: " + log.getCarServiceId());
        } catch (Exception e) {
            System.out.println("❌ Failed to publish message to Kafka: " + e.getMessage());
        }
    }
}