package com.example.carservice.service;

import java.util.List;

import com.example.carservice.model.CarService;

/**
 * Service interface defining operations for managing
 * {@link CarService} entities.
 * <p>
 * This interface declares methods for performing CRUD operations
 * such as create, read, update, and delete on car service records.
 * </p>
 *
 * <p>
 * Implementations of this interface should contain business logic
 * and validations as required by the application.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface CarServiceService {
	/**
     * Retrieves all car service records.
     *
     * @return a list of {@link CarService} objects
     */
	List<CarService> getAll();

	/**
     * Saves a new car service record.
     *
     * @param carService the {@link CarService} object to be saved
     * @return the saved {@link CarService}
     */
	CarService save(CarService carService); //POST
	
	/**
     * Retrieves a car service record by its unique identifier.
     *
     * @param id the ID of the car service
     * @return the corresponding {@link CarService}
     */
    CarService getById(Long id);	//GET
    
    /**
     * Deletes a car service record by its unique identifier.
     *
     * @param id the ID of the car service to delete
     */

    void deleteById(Long id);	//DELETE

/**
     * Updates an existing car service record.
     *
     * @param id the ID of the car service to update
     * @param updatedCarService the updated {@link CarService} object
     * @return the updated {@link CarService}
     */
    CarService updateById(Long id, CarService updatedCarService);  //UPDATE
}
