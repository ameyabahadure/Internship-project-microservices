package com.example.carservice.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.carservice.util.SecurityUtils;
import com.example.carservice.dto.AuditLogDTO;
import com.example.carservice.exception.DuplicateResourceException;
import com.example.carservice.exception.ResourceNotFoundException;
import com.example.carservice.model.CarService;
import com.example.carservice.producer.CarServiceProducer;
import com.example.carservice.repo.CarServiceRepository;

/**
 * Service implementation class for managing {@link CarService} operations.
 * <p>
 * This class provides business logic for handling CRUD operations,
 * validation, and integration with external services such as validation
 * service and Kafka producer for audit logging.
 * </p>
 *
 * <p>
 * It ensures transactional integrity and applies validation rules
 * before persisting or updating records.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Service
public class CarServiceImpl implements CarServiceService {


/**
     * Repository for accessing CarService data.
     */
    private final CarServiceRepository repo;

    /**
     * Client for validating car registration details.
     */
    private final ValidationClient validationClient;

    /**
     * Kafka producer for sending audit log events.
     */
    private final CarServiceProducer producer;

    // Clean constructor injection across all dependencies

    /**
     * Constructs a new {@code CarServiceImpl} with required dependencies.
     *
     * @param repo repository for persistence operations
     * @param validationClient client for car validation
     * @param producer Kafka producer for audit logs
     */
    public CarServiceImpl(CarServiceRepository repo, ValidationClient validationClient, CarServiceProducer producer) {
        this.repo = repo;
        this.validationClient = validationClient;
        this.producer = producer;
    }
    

/**
     * Retrieves all car service records.
     *
     * @return list of all {@link CarService} objects
     */

    @Override
    public List<CarService> getAll() {
    	
        return repo.findAll();
    }
    

/**
     * Saves a new car service record after performing validations.
     *
     * @param carService the {@link CarService} object to save
     * @return the saved {@link CarService}
     * @throws IllegalArgumentException if service date is invalid
     * @throws DuplicateResourceException if duplicate registration exists
     * @throws RuntimeException if validation fails
     */

    @Override
    @Transactional
    public CarService save(CarService carService) {
        if (carService.getServiceDate() == null) {
            throw new IllegalArgumentException("Service date is required");
        }

        if (carService.getServiceDate().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Service date cannot be in the future");
        }

        if (repo.existsByCarRegistrationNumber(carService.getCarRegistrationNumber())) {
            throw new DuplicateResourceException("Car with registration number already exists");
        }

        Boolean valid = validationClient.validateCar(carService.getCarRegistrationNumber());
        if (valid == null || !valid) {
            throw new RuntimeException("Invalid car registration number validation failed");
        }

        CarService saved = repo.save(carService);
        
        //extract the username JWT token
        String user = SecurityUtils.getCurrentUsername(); 
        
        // Dispatch Event Async to Kafka Cluster
        AuditLogDTO log = new AuditLogDTO(saved.getId(), "CREATE", user, "New car service registered successfully");
        producer.sendCarEvent(log);

        return saved;
    }
    

/**
     * Retrieves a car service record by its ID.
     *
     * @param id the unique identifier of the car service
     * @return the found {@link CarService}
     * @throws ResourceNotFoundException if no record exists
     */

    @Override
    public CarService getById(Long id) {
        CarService result = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Car service record not found with id: " + id));
        
        //extract the username JWT token
        String user = SecurityUtils.getCurrentUsername();
        
        AuditLogDTO log = new AuditLogDTO(id, "GET", user, "Car service record fetched");
        producer.sendCarEvent(log);
        
        return result;
    }
    
/**
     * Deletes a car service record by its ID.
     *
     * @param id the unique identifier of the car service
     * @throws ResourceNotFoundException if record does not exist
     */

    @Override
    @Transactional
    public void deleteById(Long id) {
        CarService existing = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Car service record not found with id: " + id));

        repo.deleteById(id);
        
        //extract the username JWT token
        String user = SecurityUtils.getCurrentUsername();
        
        AuditLogDTO log = new AuditLogDTO(id, "DELETED", user, "Car service record removed");
        producer.sendCarEvent(log);
    }
   
/**
     * Updates an existing car service record.
     *
     * @param id the unique identifier of the record to update
     * @param updatedCarService the updated {@link CarService} object
     * @return the updated {@link CarService}
     * @throws ResourceNotFoundException if record does not exist
     * @throws IllegalArgumentException if updated date is invalid
     */

    @Override
    @Transactional
    public CarService updateById(Long id, CarService updatedCarService) {
        CarService existing = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Car service record not found with id: " + id));

        if (updatedCarService.getServiceDate() != null && updatedCarService.getServiceDate().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Updated service date cannot be in the future");
        }

        existing.setCarRegistrationNumber(updatedCarService.getCarRegistrationNumber());
        existing.setCustomerId(updatedCarService.getCustomerId());
        existing.setServiceType(updatedCarService.getServiceType());
        existing.setServiceDate(updatedCarService.getServiceDate());
        existing.setServiceStatus(updatedCarService.getServiceStatus());
        existing.setNotes(updatedCarService.getNotes());

        CarService saved = repo.save(existing);
        
        //extract the username JWT token
        String user = SecurityUtils.getCurrentUsername();
        
        AuditLogDTO log = new AuditLogDTO(saved.getId(), "UPDATE", user, "Car service log values modified");
        producer.sendCarEvent(log);

        return saved;
    }
}