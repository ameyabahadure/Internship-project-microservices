package com.example.carservice.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.Optional;

import com.example.carservice.exception.DuplicateResourceException;
import com.example.carservice.exception.ResourceNotFoundException;
import com.example.carservice.model.CarService;
import com.example.carservice.producer.CarServiceProducer;
import com.example.carservice.repo.CarServiceRepository;
import com.example.carservice.service.CarServiceImpl;
import com.example.carservice.service.ValidationClient;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CarServiceServiceTest {

    @Mock
    private CarServiceRepository repo;

    @Mock
    private ValidationClient validationClient;

    @Mock
    private CarServiceProducer producer;

    @InjectMocks
    private CarServiceImpl service;

    // ✅ save() SUCCESS

    @Test
    void testSaveSuccess() {

        CarService car = new CarService();
        car.setCarRegistrationNumber("TN01");
        car.setServiceDate(LocalDate.now());

        Mockito.when(repo.existsByCarRegistrationNumber("TN01")).thenReturn(false);
        Mockito.when(validationClient.validateCar("TN01")).thenReturn(true);
        Mockito.when(repo.save(Mockito.any())).thenReturn(car);

        CarService result = service.save(car);

        assertEquals("TN01", result.getCarRegistrationNumber());
    }

    // ✅ save() DUPLICATE

    @Test
    void testSaveDuplicate() {

        CarService car = new CarService();
        car.setCarRegistrationNumber("TN01");
        car.setServiceDate(LocalDate.now());

        Mockito.when(repo.existsByCarRegistrationNumber("TN01")).thenReturn(true);

        assertThrows(DuplicateResourceException.class,
                () -> service.save(car));
    }

    // ✅ getById() SUCCESS

    @Test
    void testGetByIdSuccess() {

        CarService car = new CarService();
        car.setId(1L);

        Mockito.when(repo.findById(1L)).thenReturn(Optional.of(car));

        assertEquals(1L, service.getById(1L).getId());
    }

    // ✅ getById() FAIL

    @Test
    void testGetByIdFail() {

        Mockito.when(repo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.getById(1L));
    }

    // ✅ deleteById() SUCCESS

    @Test
    void testDeleteSuccess() {

        CarService car = new CarService();
        car.setId(1L);

        Mockito.when(repo.findById(1L)).thenReturn(Optional.of(car));

        service.deleteById(1L);

        Mockito.verify(repo).deleteById(1L);
    }

    // ✅ deleteById() FAIL

    @Test
    void testDeleteFail() {

        Mockito.when(repo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.deleteById(1L));
    }

    // ✅ updateById() SUCCESS

    @Test
    void testUpdateSuccess() {

        CarService car = new CarService();
        car.setId(1L);
        car.setServiceDate(LocalDate.now());

        Mockito.when(repo.findById(1L)).thenReturn(Optional.of(car));
        Mockito.when(repo.save(Mockito.any())).thenReturn(car);

        CarService updated = service.updateById(1L, car);

        assertEquals(1L, updated.getId());
    }

    // ✅ updateById() FAIL

    @Test
    void testUpdateFail() {

        CarService car = new CarService();

        Mockito.when(repo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.updateById(1L, car));
    }
}
