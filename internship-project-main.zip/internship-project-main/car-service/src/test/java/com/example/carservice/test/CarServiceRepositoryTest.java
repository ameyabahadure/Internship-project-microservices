package com.example.carservice.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.List;

import com.example.carservice.enums.ServiceStatus;
import com.example.carservice.enums.ServiceType;
import com.example.carservice.model.CarService;
import com.example.carservice.repo.CarServiceRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jpa.test.autoconfigure.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

@DataJpaTest
@ActiveProfiles("test")
class CarServiceRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private CarServiceRepository repo;

    // ✅ findAll() TEST

    @Test
    void testFindAll() {

        CarService car = new CarService();
        car.setCarRegistrationNumber("TN01");
        car.setCustomerId(100L); 
        car.setServiceDate(LocalDate.now()); 
        car.setServiceType(ServiceType.OIL_CHANGE); 
        car.setServiceStatus(ServiceStatus.PENDING); 

        entityManager.persist(car);
        entityManager.flush();

        List<CarService> list = repo.findAll();

        assertEquals(1, list.size());
    }

    // ✅ existsByCarRegistrationNumber()

    @Test
    void testExists() {

        CarService car = new CarService();
        car.setCarRegistrationNumber("TN01");
        car.setCustomerId(100L); 
        car.setServiceDate(LocalDate.now()); 
        car.setServiceType(ServiceType.OIL_CHANGE); 
        car.setServiceStatus(ServiceStatus.PENDING); 

        entityManager.persist(car);
        entityManager.flush();

        assertTrue(repo.existsByCarRegistrationNumber("TN01"));
    }

}

