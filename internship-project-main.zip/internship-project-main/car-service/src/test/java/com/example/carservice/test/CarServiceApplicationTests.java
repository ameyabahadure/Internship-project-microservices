package com.example.carservice.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
