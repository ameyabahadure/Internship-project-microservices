package com.example.carservice.test;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import com.example.carservice.exception.ResourceNotFoundException;
import com.example.carservice.model.CarService;
import com.example.carservice.service.CarServiceService;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
class CarServiceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CarServiceService service;

    // ✅ GET ALL (2 test cases)

    @Test
    void testGetAll() throws Exception {

        List<CarService> list = new ArrayList<>();
        list.add(new CarService());

        Mockito.when(service.getAll()).thenReturn(list);

        mockMvc.perform(get("/carservice"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAllEmpty() throws Exception {

        Mockito.when(service.getAll()).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/carservice"))
                .andExpect(status().isOk());
    }

    // ✅ GET BY ID (2 test cases)

    @Test
    void testGetByIdSuccess() throws Exception {

        CarService car = new CarService();
        car.setId(1L);

        when(service.getById(1L)).thenReturn(car);

        mockMvc.perform(get("/carservice/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)));
    }

    @Test
    void testGetByIdFail() throws Exception {

        when(service.getById(1L))
                .thenThrow(new ResourceNotFoundException("Not found"));

        mockMvc.perform(get("/carservice/1"))
                .andExpect(status().isNotFound());
    }

    // ✅ SAVE (2 test cases)

    @Test
    void testSaveSuccess() throws Exception {

        CarService car = new CarService();
        car.setId(1L);

        when(service.save(Mockito.any())).thenReturn(car);

        mockMvc.perform(post("/carservice/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isCreated());
    }

    @Test
    void testSaveFail() throws Exception {

        when(service.save(Mockito.any()))
                .thenThrow(new RuntimeException());

        mockMvc.perform(post("/carservice/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isInternalServerError());
    }
}