package com.example.audit.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * Security configuration class for defining application security policies.
 * <p>
 * This class configures:
 * <ul>
 *     <li>JWT-based authentication</li>
 *     <li>Role-based access control</li>
 *     <li>CORS settings</li>
 *     <li>CSRF disabling for stateless APIs</li>
 *     <li>Integration of custom {@link JwtFilter}</li>
 * </ul>
 * </p>
 *
 * <p>
 * The application follows a stateless session policy using JWT tokens.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Configuration
public class SecurityConfig {

	/**
     * Custom JWT filter used for validating and processing tokens.
     */

    private final JwtFilter jwtFilter;

    /**
     * Constructs a new {@code SecurityConfig} with the provided JWT filter.
     *
     * @param jwtFilter the JWT filter to be applied
     */

    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    /**
     * Configures the security filter chain for handling HTTP security.
     * <p>
     * This method defines:
     * <ul>
     *     <li>CSRF disabled configuration</li>
     *     <li>CORS enabled configuration</li>
     *     <li>H2 console frame settings</li>
     *     <li>Role-based authorization rules</li>
     *     <li>Stateless session management</li>
     *     <li>JWT filter integration</li>
     * </ul>
     *
     * @param http the {@link HttpSecurity} object to configure
     * @return the configured {@link SecurityFilterChain}
     * @throws Exception in case of configuration errors
     */

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            // Disable CSRF
            .csrf(csrf -> csrf.disable())

            // Enable CORS
            .cors(cors -> {})

            // Allow H2 console iframe
            .headers(headers -> headers
                .frameOptions(frame -> frame.disable())
            )

            // ROLE-BASED AUTHORIZATION
            .authorizeHttpRequests(auth -> auth

                // PUBLIC ENDPOINTS
                .requestMatchers("/h2-console/**").permitAll()
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()

                // GET -> ADMIN + USER
                .requestMatchers(HttpMethod.GET, "/audit/**")
                    .hasAnyRole("ADMIN")

                // POST -> ADMIN ONLY
                .requestMatchers(HttpMethod.POST, "/audit/**")
                    .hasRole("ADMIN")

                // PUT -> ADMIN ONLY
                .requestMatchers(HttpMethod.PUT, "/audit/**")
                    .hasRole("ADMIN")

                // DELETE -> ADMIN ONLY
                .requestMatchers(HttpMethod.DELETE, "/audit/**")
                    .hasRole("ADMIN")

                // Any other request must be authenticated
                .anyRequest().authenticated()
            )

            // Stateless (JWT)
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            );

        // ✅ Add JWT filter before auth filter
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // CORS CONFIG
    /**
     * Configures CORS (Cross-Origin Resource Sharing) settings.
     * <p>
     * This configuration:
     * <ul>
     *     <li>Allows all origins (for development use)</li>
     *     <li>Allows all headers and HTTP methods</li>
     *     <li>Enables credentials sharing</li>
     *     <li>Exposes Authorization header</li>
     * </ul>
     *
     * @return the configured {@link CorsConfigurationSource}
     */

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration config = new CorsConfiguration();

        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*");   // allow all origins (dev)
        config.addAllowedHeader("*");          // allow all headers
        config.addAllowedMethod("*");          // GET, POST, PUT, DELETE

        config.addExposedHeader("Authorization");

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);

        return source;
    }
}