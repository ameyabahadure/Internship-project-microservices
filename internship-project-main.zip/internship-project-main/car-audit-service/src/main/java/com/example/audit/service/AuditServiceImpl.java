package com.example.audit.service;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.audit.exception.BadRequestException;
import com.example.audit.exception.ResourceNotFoundException;
import com.example.audit.model.CarServiceAuditLog;
import com.example.audit.repo.AuditRespository;

/**
 * Service implementation for handling audit log operations.
 * <p>
 * This class provides business logic for validating and persisting
 * {@link CarServiceAuditLog} records, as well as retrieving audit logs
 * from the database.
 * </p>
 *
 * <p>
 * It ensures input validation and applies transactional integrity
 * during database operations.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Service
public class AuditServiceImpl implements AuditService {

	/**
     * Repository for performing database operations on audit logs.
     */
	
    private final AuditRespository repository;

    /**
     * Constructs a new {@code AuditServiceImpl} with the specified repository.
     *
     * @param repository the repository used for audit log persistence
     */
	
    public AuditServiceImpl(AuditRespository repository) {
        this.repository = repository;
    }

    /**
     * Saves an audit log entry after validating input data.
     *
     * @param log the {@link CarServiceAuditLog} object to be saved
     * @return the saved {@link CarServiceAuditLog}
     * @throws BadRequestException if input validation fails
     */

    @Override
    @Transactional
    public CarServiceAuditLog saveLog(CarServiceAuditLog log) {
		
        if (log == null) {
            throw new BadRequestException("Audit log payload cannot be null");
        }

        if (log.getCarServiceId() == null || log.getCarServiceId() <= 0) {
            throw new BadRequestException("A valid Car Service ID is required");
        }

        if (log.getAction() == null || log.getAction().trim().isBlank()) {
            throw new BadRequestException("Action is required and cannot be empty");
        }

        if (log.getPerformedBy() == null || log.getPerformedBy().trim().isBlank()) {
            throw new BadRequestException("PerformedBy identity is required");
        }

        log.setTimestamp(LocalDateTime.now());
		
        return repository.save(log);
    }

    /**
     * Retrieves all audit log records from the database.
     *
     * @return a list of {@link CarServiceAuditLog} objects
     * @throws ResourceNotFoundException if no records are found
     */

    @Override
    public List<CarServiceAuditLog> getAll() {
        List<CarServiceAuditLog> logs = repository.findAll();

        if (logs == null || logs.isEmpty()) {
            throw new ResourceNotFoundException("No audit logs found in the database");
        }
        return logs;
    }
}