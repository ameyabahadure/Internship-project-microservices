package com.example.audit.feign;

import feign.RequestInterceptor;

import feign.RequestTemplate;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;

 /**
 * Feign client interceptor for propagating authorization headers.
 * <p>
 * This interceptor captures the incoming HTTP request's Authorization header
 * and forwards it to outgoing Feign client requests.
 * </p>
 *
 * <p>
 * It ensures secure communication between microservices by passing along
 * JWT or other authentication tokens.
 * </p>
 *
 * <p>
 * Typically used in API gateway or microservice architectures where
 * authentication context needs to be shared across services.
 * </p>
 *
 * @author
 * @since 1.0
 */
 
@Configuration
public class FeignClientInterceptor implements RequestInterceptor {

	/**
     * HTTP servlet request used to extract incoming request headers.
     */
 
    @Autowired
    private HttpServletRequest request;

    /**
     * Applies the interceptor logic to outgoing Feign requests.
     * <p>
     * Extracts the "Authorization" header from the incoming request
     * and adds it to the Feign request template if present.
     * </p>
     *
     * @param template the Feign request template to modify
     */
 
    @Override
    public void apply(RequestTemplate template) {
 
        String token = request.getHeader("Authorization");
 
        if (token != null) {

            template.header("Authorization", token);

        }

    }

}

 
