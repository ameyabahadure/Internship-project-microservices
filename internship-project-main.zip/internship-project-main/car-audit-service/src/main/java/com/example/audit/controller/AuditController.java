package com.example.audit.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.audit.model.CarServiceAuditLog;
import com.example.audit.service.AuditService;

/**
 * REST controller for handling audit log operations.
 * <p>
 * This controller exposes endpoints to create and retrieve
 * audit logs related to car service actions.
 * </p>
 *
 * <p>
 * Base URL mapping: /audit
 * </p>
 *
 * @author
 * @since 1.0
 */

@RestController
@RequestMapping("/audit")
public class AuditController {

	/**
     * Service layer dependency for managing audit logs.
     */
    private final AuditService auditService;

    /**
     * Constructs a new {@code AuditController} with the provided service.
     *
     * @param auditService the service responsible for audit log operations
     */
    //Replaced loose @Autowired field with safe constructor injection
    public AuditController(AuditService auditService) {
        this.auditService = auditService;
    }

    /**
     * Creates a new audit log entry.
     *
     * @param log the {@link CarServiceAuditLog} object containing audit details
     * @return the saved {@link CarServiceAuditLog} wrapped in a {@link ResponseEntity}
     */

    @PostMapping("/log")
    public ResponseEntity<CarServiceAuditLog> log(@RequestBody CarServiceAuditLog log) {
        return ResponseEntity.ok(auditService.saveLog(log));
    }

    /**
     * Retrieves all audit log records.
     *
     * @return a list of {@link CarServiceAuditLog} wrapped in a {@link ResponseEntity}
     */

    @GetMapping
    public ResponseEntity<List<CarServiceAuditLog>> getAll() {
        return ResponseEntity.ok(auditService.getAll());
    }
}