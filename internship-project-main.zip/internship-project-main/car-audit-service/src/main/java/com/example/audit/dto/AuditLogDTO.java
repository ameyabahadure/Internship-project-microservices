package com.example.audit.dto;
import java.time.LocalDateTime;

/**
 * Data Transfer Object (DTO) representing audit log details.
 * <p>
 * This class is used to transfer audit-related information between
 * different layers of the application or across microservices.
 * </p>
 *
 * <p>
 * It contains details about the action performed on a car service,
 * the user who performed it, and additional descriptive information.
 * </p>
 *
 * <p>
 * Note: Timestamp field is currently commented out and may be used
 * in future enhancements for tracking event time.
 * </p>
 *
 * @author
 * @since 1.0
 */

public class AuditLogDTO {

	/**
     * Identifier of the associated car service record.
     */
    private Long carServiceId;

    /**
     * Action performed (e.g., CREATE, UPDATE, DELETE).
     */
    private String action;

    /**
     * Username or identifier of the user who performed the action.
     */
    private String performedBy;

    /**
     * Additional details describing the action.
     */
    private String details;
    
    //private LocalDateTime timestamp;
    
    // getters setters
    /**
     * Gets the car service ID.
     *
     * @return the car service ID
     */
	public Long getCarServiceId() {
		return carServiceId;
	}

	/**
     * Sets the car service ID.
     *
     * @param carServiceId the ID to set
     */
	public void setCarServiceId(Long carServiceId) {
		this.carServiceId = carServiceId;
	}

	/**
     * Gets the action performed.
     *
     * @return the action
     */
	public String getAction() {
		return action;
	}

	/**
     * Sets the action performed.
     *
     * @param action the action to set
     */
	public void setAction(String action) {
		this.action = action;
	}

	/**
     * Gets the user who performed the action.
     *
     * @return the username or identifier
     */
	public String getPerformedBy() {
		return performedBy;
	}

	/**
     * Sets the user who performed the action.
     *
     * @param performedBy the user identifier to set
     */
	public void setPerformedBy(String performedBy) {
		this.performedBy = performedBy;
	}

	/**
     * Gets additional details of the audit log.
     *
     * @return the details
     */
	public String getDetails() {
		return details;
	}

	/**
     * Sets additional details of the audit log.
     *
     * @param details the details to set
     */
	public void setDetails(String details) {
		this.details = details;
	}
 
}

