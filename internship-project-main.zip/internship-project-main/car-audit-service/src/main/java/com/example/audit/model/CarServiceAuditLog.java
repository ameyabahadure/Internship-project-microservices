package com.example.audit.model;
import java.time.LocalDateTime;

import org.antlr.v4.runtime.misc.NotNull;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

/**
 * Entity representing audit log records for car service operations.
 * <p>
 * This class maps to the "car_service_audit_logs" table and stores
 * information about actions performed on car services, including
 * the user who performed the action, timestamp, and additional details.
 * </p>
 *
 * <p>
 * It uses JPA annotations for ORM mapping and lifecycle callbacks
 * to manage default timestamp values.
 * </p>
 *
 * @author
 * @since 1.0
 */
@Entity
@Table(name = "car_service_audit_logs")
public class CarServiceAuditLog {

    /**
     * Unique identifier for the audit log record.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Identifier of the associated car service record.
     */
    @Column(name = "car_service_id")
    private Long carServiceId;

    /**
     * Action performed on the car service (e.g., CREATE, UPDATE, DELETE).
     */
    @NotNull
    @Column(name = "action", nullable = false, length = 50)
    private String action;

    /**
     * Timestamp indicating when the action occurred.
     */
    @NotNull
    @Column(name = "timestamp", nullable = false)
    private LocalDateTime timestamp;

    /**
     * Username or identifier of the user who performed the action.
     */
    @NotNull
    @Column(name = "performed_by", nullable = false, length = 100)
    private String performedBy;

    /**
     * Additional descriptive details about the action.
     */
    @Column(name = "details", columnDefinition = "TEXT")
    private String details;

    /**
     * Default constructor required by JPA.
     */
    public CarServiceAuditLog() {}

    /**
     * Parameterized constructor to initialize audit log fields.
     *
     * @param carServiceId the associated car service ID
     * @param action the action performed
     * @param timestamp the timestamp of the action
     * @param performedBy the user who performed the action
     * @param details additional details of the action
     */
    public CarServiceAuditLog(Long carServiceId, String action,
                             LocalDateTime timestamp, String performedBy, String details) {
        this.carServiceId = carServiceId;
        this.action = action;
        this.timestamp = timestamp;
        this.performedBy = performedBy;
        this.details = details;
    }

    //timestamp if not provided

    /**
     * Lifecycle callback method executed before persisting the entity.
     * <p>
     * Automatically sets the timestamp if it is not already provided.
     * </p>
     */
    @PrePersist
    protected void onCreate() {
        if (this.timestamp == null) {
            this.timestamp = LocalDateTime.now();
        }
    }
    
    /**
     * Sets the audit log ID.
     *
     * @param id the ID to set
     */
    public void setId(Long id) {
            this.id= id;
    }
    
    /**
     * Gets the audit log ID.
     *
     * @return the ID
     */
    public Long getId() {
        return id;
    }

    /**
     * Gets the car service ID.
     *
     * @return the car service ID
     */
    public Long getCarServiceId() {
        return carServiceId;
    }

    /**
     * Sets the car service ID.
     *
     * @param carServiceId the ID to set
     */
    public void setCarServiceId(Long carServiceId) {
        this.carServiceId = carServiceId;
    }

    /**
     * Gets the action performed.
     *
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the action performed.
     *
     * @param action the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * Gets the timestamp of the action.
     *
     * @return the timestamp
     */
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the timestamp of the action.
     *
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Gets the user who performed the action.
     *
     * @return the user identifier
     */
    public String getPerformedBy() {
        return performedBy;
    }

    /**
     * Sets the user who performed the action.
     *
     * @param performedBy the user identifier to set
     */
    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    /**
     * Gets additional details of the audit log.
     *
     * @return the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * Sets additional details of the audit log.
     *
     * @param details the details to set
     */
    public void setDetails(String details) {
        this.details = details;
    }
}