package com.example.audit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.audit.model.CarServiceAuditLog;

/**
 * Repository interface for performing CRUD operations on
 * {@link CarServiceAuditLog} entities.
 * <p>
 * This interface extends {@link JpaRepository}, providing built-in
 * methods for interacting with the database such as save, update,
 * delete, and retrieval of audit log records.
 * </p>
 *
 * <p>
 * It eliminates the need for writing boilerplate DAO code and enables
 * seamless integration with Spring Data JPA.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface AuditRespository extends JpaRepository<CarServiceAuditLog, Long>{

}
