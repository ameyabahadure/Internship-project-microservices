package com.example.audit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;

 /**
 * Main entry point for the Car Audit Service application.
 * <p>
 * This class bootstraps the Spring Boot application and enables
 * Kafka support for handling asynchronous messaging operations.
 * </p>
 *
 * <p>
 * It uses:
 * <ul>
 *     <li>{@link SpringBootApplication} for auto-configuration and component scanning</li>
 *     <li>{@link EnableKafka} to enable Kafka listener infrastructure</li>
 * </ul>
 * </p>
 *
 * @author
 * @since 1.0
 */

@SpringBootApplication
@EnableKafka
public class CarAuditServiceApplication {

	/**
     * Main method used to launch the Spring Boot application.
     *
     * @param args command-line arguments
     */

	public static void main(String[] args) {
		SpringApplication.run(CarAuditServiceApplication.class, args);
	}

}
