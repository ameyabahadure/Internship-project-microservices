package com.example.audit.service;

import java.util.List;

import com.example.audit.model.CarServiceAuditLog;

/**
 * Service interface for managing audit log operations.
 * <p>
 * This interface defines methods for persisting and retrieving
 * {@link CarServiceAuditLog} records.
 * </p>
 *
 * <p>
 * Implementations of this interface should handle business logic
 * related to audit logging, including validation and persistence.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface AuditService {

	/**
     * Saves an audit log entry.
     *
     * @param log the {@link CarServiceAuditLog} object to be saved
     * @return the saved {@link CarServiceAuditLog}
     */
	CarServiceAuditLog saveLog(CarServiceAuditLog log);
	
	/**
     * Retrieves all audit log records.
     *
     * @return a list of {@link CarServiceAuditLog} objects
     */
	List<CarServiceAuditLog> getAll();
}

