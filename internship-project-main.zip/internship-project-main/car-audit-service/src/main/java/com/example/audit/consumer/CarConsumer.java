package com.example.audit.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import com.example.audit.model.CarServiceAuditLog;
import com.example.audit.service.AuditService;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

 /**
 * Kafka consumer component responsible for processing audit events
 * from the "car-audit-topic".
 * <p>
 * This class listens to incoming Kafka messages, parses the event data,
 * transforms it into {@link CarServiceAuditLog} entities, and persists
 * them using the {@link AuditService}.
 * </p>
 *
 * <p>
 * It uses Jackson {@link ObjectMapper} for JSON parsing and Spring Kafka
 * for asynchronous message consumption.
 * </p>
 *
 * <p>
 * Error handling is implemented to catch parsing and persistence issues,
 * ensuring that failures do not disrupt the consumer process.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Component
public class CarConsumer {

	/**
     * ObjectMapper instance for parsing JSON event messages.
     */
    private final ObjectMapper mapper = new ObjectMapper();

    /**
     * Service responsible for persisting audit logs.
     */
    private final AuditService auditService;

    /**
     * Constructs a new {@code CarConsumer} with the required audit service.
     *
     * @param auditService the service used to handle audit log persistence
     */
    public CarConsumer(AuditService auditService) {
        this.auditService = auditService;
    }

/**
     * Consumes audit events from Kafka topic and processes them.
     * <p>
     * This method:
     * <ul>
     *     <li>Receives raw JSON message from Kafka</li>
     *     <li>Parses the JSON into a map structure</li>
     *     <li>Extracts required fields dynamically</li>
     *     <li>Builds {@link CarServiceAuditLog} entity</li>
     *     <li>Persists the entity to the database</li>
     * </ul>
     *
     * @param event the raw JSON string received from Kafka topic
     */
    
    @KafkaListener(topics = "car-audit-topic", groupId = "audit-group")
    public void consumeAuditEvent(String event) {
        try {
            System.out.println("Received raw Kafka event message: " + event);

            // Parse incoming event data array map
            Map<String, Object> data = mapper.readValue(event, Map.class);

            // Dynamic type extraction verification check
            Long carServiceId = data.get("carServiceId") != null ? ((Number) data.get("carServiceId")).longValue() : null;
            String action = (String) data.get("action");
            String performedBy = (String) data.get("performedBy");
            String details = (String) data.get("details");

            // Build our tracking model entity target
            CarServiceAuditLog auditLog = new CarServiceAuditLog();
            auditLog.setCarServiceId(carServiceId);
            auditLog.setAction(action);
            auditLog.setPerformedBy(performedBy);
            auditLog.setDetails(details);

            System.out.println("🔄 Routing log data to Database for CarService ID: " + carServiceId);

            // Persist to MySQL
            CarServiceAuditLog savedLog = auditService.saveLog(auditLog);

            System.out.println("Audit Log successfully saved to database with ID: " + savedLog.getId() +
                               " | Action: " + savedLog.getAction());

        } catch (Exception e) {
            System.err.println("Error processing or saving audit log entry: " + e.getMessage());
            e.printStackTrace();
        }
    }
}