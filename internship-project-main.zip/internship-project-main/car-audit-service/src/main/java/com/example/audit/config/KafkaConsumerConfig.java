package com.example.audit.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

 /**
 * Configuration class for setting up Kafka consumer properties.
 * <p>
 * This class defines beans required for consuming messages from
 * a Kafka cluster, including the consumer factory and listener
 * container factory.
 * </p>
 *
 * <p>
 * It configures:
 * <ul>
 *     <li>Kafka broker connection</li>
 *     <li>Consumer group ID</li>
 *     <li>Key and value deserializers</li>
 *     <li>Listener container factory for concurrent message processing</li>
 * </ul>
 * </p>
 *
 * @author
 * @since 1.0
 */

@Configuration
public class KafkaConsumerConfig {

	/**
     * Creates a Kafka {@link ConsumerFactory} with specified configuration properties.
     *
     * @return a configured {@link ConsumerFactory} instance
     */

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "audit-group");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        
        return new DefaultKafkaConsumerFactory<>(props);
    }
    
    /**
     * Creates a Kafka listener container factory for managing
     * concurrent message listeners.
     *
     * @return a configured {@link ConcurrentKafkaListenerContainerFactory} instance
     */

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = 
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
}