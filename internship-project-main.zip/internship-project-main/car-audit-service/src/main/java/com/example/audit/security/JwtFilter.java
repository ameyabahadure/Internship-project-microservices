package com.example.audit.security;

import jakarta.servlet.FilterChain;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;
 
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

import io.jsonwebtoken.Claims;

import io.jsonwebtoken.Jwts;

import io.jsonwebtoken.security.Keys;
 
 
import javax.crypto.SecretKey;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

 /**
 * JWT filter responsible for validating incoming HTTP requests.
 * <p>
 * This filter intercepts requests, extracts JWT tokens from the
 * Authorization header, validates them, and sets authentication
 * details in the Spring Security context.
 * </p>
 *
 * <p>
 * It performs:
 * <ul>
 *     <li>Token presence validation</li>
 *     <li>JWT signature verification</li>
 *     <li>Expiration check</li>
 *     <li>Extraction of username and roles</li>
 *     <li>Creation of authentication object</li>
 * </ul>
 * </p>
 *
 * <p>
 * Requests for H2 console and Swagger endpoints are excluded from filtering.
 * </p>
 *
 * @author
 * @since 1.0
 */
 
@Component
public class JwtFilter extends OncePerRequestFilter {

	/**
     * Secret key used for signing and validating JWT tokens.
     */

    private final String SECRET = "X9aB7cQmP4tR2vL8wZ6yN0kD3fH5jG1uE7oS4nM2bV9rT8qC5xJ";
 
//    FOR H2 CONSOLE

    /**
     * Determines whether the filter should be applied to the current request.
     * <p>
     * Skips filtering for H2 console and Swagger endpoints.
     * </p>
     *
     * @param request the HTTP request
     * @return {@code true} if filtering should be skipped, otherwise {@code false}
     */

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {

        String path = request.getRequestURI();

        return path.startsWith("/h2-console") || path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs");

    }


    /**
     * Filters incoming HTTP requests to validate JWT tokens.
     * <p>
     * This method:
     * <ul>
     *     <li>Extracts JWT from Authorization header</li>
     *     <li>Validates token signature and expiration</li>
     *     <li>Parses claims (username and roles)</li>
     *     <li>Creates authentication and sets it in security context</li>
     * </ul>
     * </p>
     *
     * @param request the HTTP request
     * @param response the HTTP response
     * @param filterChain the filter chain
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
 
    @Override
    protected void doFilterInternal(HttpServletRequest request,

                                   HttpServletResponse response,

                                   FilterChain filterChain)

            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        // No token case

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().write("JWT token is missing");

            return;

        }

        String token = authHeader.substring(7);

        try {

            SecretKey key = Keys.hmacShaKeyFor(SECRET.getBytes());

            // Parse token

            Claims claims = Jwts.parserBuilder()

                    .setSigningKey(key)

                    .build()

                    .parseClaimsJws(token)

                    .getBody();

            // Check expiry

            if (claims.getExpiration().before(new Date())) {

                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

                response.getWriter().write("JWT expired");

                return;

            }
            
            String username = claims.getSubject();
            

         //Extract ROLES from JWT
            String roles = claims.get("role", String.class);

  List<SimpleGrantedAuthority> authorities = Arrays.stream(roles.split(","))
                             .map(String::trim)
                             .map(SimpleGrantedAuthority::new) // expects ROLE_ADMIN, ROLE_USER
                             .collect(Collectors.toList());



  		   // Create authentication WITH ROLES
           UsernamePasswordAuthenticationToken authentication =
                   new UsernamePasswordAuthenticationToken(
                           username,
                           null,
                           authorities
                   );


            SecurityContextHolder.getContext().setAuthentication(authentication);

        } catch (Exception e) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().write("Invalid JWT token");

            return;

        }

        filterChain.doFilter(request, response);

    }

}

 
