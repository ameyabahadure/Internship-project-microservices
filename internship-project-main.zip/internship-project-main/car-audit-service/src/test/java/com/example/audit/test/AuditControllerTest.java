package com.example.audit.test;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import com.example.audit.model.CarServiceAuditLog;
import com.example.audit.service.AuditService;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class AuditControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private AuditService service;

    // ✅ getAll()

    @Test
    void testGetAllSuccess() throws Exception {

        List<CarServiceAuditLog> list = new ArrayList<>();
        list.add(new CarServiceAuditLog());

        when(service.getAll()).thenReturn(list);

        mockMvc.perform(get("/audit"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAllEmptyFail() throws Exception {

        when(service.getAll())
                .thenThrow(new RuntimeException());

        mockMvc.perform(get("/audit"))
                .andExpect(status().is5xxServerError());
    }

    // ✅ save()

    @Test
    void testSaveSuccess() throws Exception {

        CarServiceAuditLog log = new CarServiceAuditLog();
        log.setId(1L);

        when(service.saveLog(Mockito.any())).thenReturn(log);

        mockMvc.perform(post("/audit/log")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)));
    }

    @Test
    void testSaveFail() throws Exception {

        when(service.saveLog(Mockito.any()))
                .thenThrow(new RuntimeException());

        mockMvc.perform(post("/audit/log")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().is5xxServerError());
    }
}
