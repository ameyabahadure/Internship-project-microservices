package com.example.audit.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.audit.repo.AuditRespository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource("classpath:application-test.properties")
class AuditIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private AuditRespository repo;

    @Test
    void testSaveIntegration() throws Exception {

        String json = """
        {
          "carServiceId":1,
          "action":"CREATE",
          "performedBy":"admin"
        }
        """;

        mockMvc.perform(post("/audit/log")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isOk());

        assertFalse(repo.findAll().isEmpty());
    }

    @Test
    void testGetAllIntegration() throws Exception {

        String json = """
        {
          "carServiceId":1,
          "action":"CREATE",
          "performedBy":"admin"
        }
        """;

        // Insert data first
        mockMvc.perform(post("/audit/log")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isOk());

        // ✅ Then fetch
        mockMvc.perform(get("/audit"))
                .andExpect(status().isOk());
    }
}
