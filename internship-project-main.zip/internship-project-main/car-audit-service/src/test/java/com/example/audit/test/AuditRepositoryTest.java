package com.example.audit.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.List;

import com.example.audit.model.CarServiceAuditLog;
import com.example.audit.repo.AuditRespository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

@DataJpaTest
class AuditRepositoryTest {

    @Autowired
    private AuditRespository repo;

    @Test
    void testSaveAndFind() {

        CarServiceAuditLog log = new CarServiceAuditLog();
        log.setCarServiceId(1L);
        log.setAction("CREATE");
        log.setPerformedBy("admin");
        log.setTimestamp(LocalDateTime.now());

        repo.save(log);

        List<CarServiceAuditLog> list = repo.findAll();

        assertEquals(1, list.size());
    }

    @Test
    void testFindEmpty() {

        List<CarServiceAuditLog> list = repo.findAll();

        assertTrue(list.isEmpty());
    }
}
