package com.example.audit.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarAuditServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
