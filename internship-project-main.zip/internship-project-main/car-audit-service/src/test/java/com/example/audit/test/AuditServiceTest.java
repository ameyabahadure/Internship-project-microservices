package com.example.audit.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.example.audit.exception.BadRequestException;
import com.example.audit.exception.ResourceNotFoundException;
import com.example.audit.model.CarServiceAuditLog;
import com.example.audit.repo.AuditRespository;
import com.example.audit.service.AuditServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AuditServiceTest {

    @Mock
    private AuditRespository repo;

    @InjectMocks
    private AuditServiceImpl service;

    // ✅ saveLog()

    @Test
    void testSaveSuccess() {

        CarServiceAuditLog log = new CarServiceAuditLog();
        log.setCarServiceId(1L);
        log.setAction("CREATE");
        log.setPerformedBy("admin");

        Mockito.when(repo.save(Mockito.any())).thenReturn(log);

        CarServiceAuditLog saved = service.saveLog(log);

        assertEquals(1L, saved.getCarServiceId());
    }

    @Test
    void testSaveFailInvalid() {

        CarServiceAuditLog log = new CarServiceAuditLog();

        assertThrows(BadRequestException.class,
                () -> service.saveLog(log));
    }

    // ✅ getAll()

    @Test
    void testGetAllSuccess() {

        Mockito.when(repo.findAll()).thenReturn(List.of(new CarServiceAuditLog()));

        assertFalse(service.getAll().isEmpty());
    }

    @Test
    void testGetAllFail() {

        Mockito.when(repo.findAll()).thenReturn(List.of());

        assertThrows(ResourceNotFoundException.class,
                () -> service.getAll());
    }
}
