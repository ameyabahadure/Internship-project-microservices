package com.example.carvalidation.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.carvalidation.model.CarValidation;

/**
 * Repository interface for performing CRUD operations on
 * {@link CarValidation} entities.
 * <p>
 * This interface extends {@link JpaRepository}, providing built-in
 * methods for common database operations such as save, delete,
 * update, and retrieval.
 * </p>
 *
 * <p>
 * It allows interaction with the "car_validation_logs" table without
 * requiring explicit SQL queries.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface CarValidationRepository extends JpaRepository<CarValidation,Long>{

}
