package com.example.carvalidation.security;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JWT filter responsible for validating incoming HTTP requests
 * for the Car Validation Service.
 * <p>
 * This filter extracts the JWT token from the Authorization header,
 * validates it, checks expiration, and sets authentication details
 * in the Spring Security context.
 * </p>
 *
 * <p>
 * It also extracts user roles from the token and assigns them
 * as authorities for role-based access control.
 * </p>
 *
 * <p>
 * Certain endpoints such as H2 console and Swagger UI are excluded
 * from filtering.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Component
public class JwtFilter extends OncePerRequestFilter {

	/**
     * Secret key used for signing and validating JWT tokens.
     */
    private final String SECRET = "X9aB7cQmP4tR2vL8wZ6yN0kD3fH5jG1uE7oS4nM2bV9rT8qC5xJ";

    /**
     * Determines whether the filter should be skipped for the given request.
     * <p>
     * Excludes H2 console and Swagger-related endpoints.
     * </p>
     *
     * @param request the HTTP request
     * @return {@code true} if filtering should be skipped, otherwise {@code false}
     */
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();

        return path.startsWith("/h2-console")
                || path.startsWith("/swagger-ui")
                || path.startsWith("/v3/api-docs")
                || path.contains("/v3/api-docs")
                || path.contains("/swagger-ui");
    }

    /**
     * Filters incoming HTTP requests to validate JWT tokens.
     * <p>
     * This method:
     * <ul>
     *     <li>Extracts JWT token from Authorization header</li>
     *     <li>Validates signature and expiration</li>
     *     <li>Parses username and roles</li>
     *     <li>Creates authentication object with authorities</li>
     *     <li>Sets authentication in security context</li>
     * </ul>
     * </p>
     *
     * @param request the HTTP request
     * @param response the HTTP response
     * @param filterChain the filter chain
     * @throws ServletException if servlet errors occur
     * @throws IOException if I/O errors occur
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("JWT token is missing");
            return;
        }

        String token = authHeader.substring(7);

        try {
            SecretKey key = Keys.hmacShaKeyFor(SECRET.getBytes());

            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            if (claims.getExpiration().before(new Date())) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("JWT expired");
                return;
            }

            String username = claims.getSubject();

            // ✅ ✅ EXTRACT ROLES
            String roles = claims.get("role", String.class);

            List<SimpleGrantedAuthority> authorities =
                    Arrays.stream(roles.split(","))
                            .map(String::trim)
                            .map(role -> {
                                if (!role.startsWith("ROLE_")) {
                                    return "ROLE_" + role;
                                }
                                return role;
                            })
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());

            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(
                            username,
                            null,
                            authorities
                    );

            SecurityContextHolder.getContext().setAuthentication(authentication);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\": \"Invalid or expired JWT token\"}");
            return;
        }

        filterChain.doFilter(request, response);
    }
}