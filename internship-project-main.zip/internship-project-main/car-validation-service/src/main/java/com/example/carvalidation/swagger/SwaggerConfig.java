package com.example.carvalidation.swagger;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.security.SecurityScheme;
 
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for setting up OpenAPI (Swagger) documentation
 * for the Car Validation Service.
 * <p>
 * This configuration defines API metadata and security settings,
 * enabling interactive API documentation through Swagger UI.
 * </p>
 *
 * <p>
 * Features configured:
 * <ul>
 *     <li>API title and version information</li>
 *     <li>JWT Bearer authentication security scheme</li>
 *     <li>Security requirements for protected endpoints</li>
 * </ul>
 * </p>
 *
 * @author
 * @since 1.0
 */
 
@Configuration
public class SwaggerConfig {

	/**
     * Creates and configures the OpenAPI bean.
     * <p>
     * This includes:
     * <ul>
     *     <li>Adding bearer authentication as a security requirement</li>
     *     <li>Defining JWT-based security scheme</li>
     *     <li>Setting API metadata such as title and version</li>
     * </ul>
     *
     * @return the configured {@link OpenAPI} instance
     */
 
	@Bean
	public OpenAPI customOpenAPI() {
		return new OpenAPI().addSecurityItem(new SecurityRequirement().addList("bearerAuth"))
				.components(new Components().addSecuritySchemes("bearerAuth",
						new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
				.info(new Info().title("Car Validation API").version("1.0"));
	}
 
}
