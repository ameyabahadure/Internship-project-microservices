package com.example.carvalidation.service;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.carvalidation.model.CarValidation;
import com.example.carvalidation.repo.CarValidationRepository;

/**
 * Service implementation for handling car validation logic.
 * <p>
 * This class provides business logic for:
 * <ul>
 *     <li>Validating car registration numbers</li>
 *     <li>Persisting validation logs</li>
 *     <li>Retrieving validation history</li>
 * </ul>
 * </p>
 *
 * <p>
 * It uses a regular expression to validate the car registration
 * format and stores validation results in the database.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Service
public class ValidationServiceImpl implements CarValidationService {

		/**
	       * Repository for performing database operations on car validation logs.
	    */	
		@Autowired
		private CarValidationRepository repository;

		/**
         * Validates a car registration number.
         * <p>
         * This method checks the car number against a predefined regex pattern
         * and stores the validation result in the database.
         * </p>
         *
         * @param carNumber the car registration number to validate
         * @return {@code true} if the car number matches the pattern, otherwise {@code false}
         */

		@Override
		public boolean validateCarNumber(String carNumber) {
			
			//use of this .matches method
			boolean isValid = carNumber.matches(
					"[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}"
			);

        CarValidation log = new CarValidation();
        log.setCarRegistrationNumber(carNumber);
        log.setIsValid(isValid);
        log.setValidationTimestamp(LocalDateTime.now());

        repository.save(log); //to save the validation log in validation_log table

        return isValid;

	}

		/**
         * Retrieves all car validation logs from the database.
         *
         * @return a list of {@link CarValidation} records
         */

		@Override
		public List<CarValidation> getAll() {
			
			return repository.findAll();
		}

	

}
