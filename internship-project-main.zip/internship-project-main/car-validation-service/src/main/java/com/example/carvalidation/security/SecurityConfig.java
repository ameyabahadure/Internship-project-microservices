package com.example.carvalidation.security;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;

/**
 * Security configuration class for the Car Validation Service.
 * <p>
 * This class configures security settings including:
 * <ul>
 *     <li>JWT-based authentication via {@link JwtFilter}</li>
 *     <li>Role-based access control (RBAC)</li>
 *     <li>CORS policy configuration</li>
 *     <li>Stateless session management</li>
 *     <li>CSRF disabling for REST APIs</li>
 * </ul>
 * </p>
 *
 * <p>
 * It ensures that endpoints are protected based on user roles
 * and integrates a custom JWT filter into the Spring Security
 * filter chain.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Configuration
public class SecurityConfig {

	/**
     * JWT filter used to validate and process authentication tokens.
     */
    private final JwtFilter jwtFilter;

    /**
     * Constructs a new {@code SecurityConfig} with the specified JWT filter.
     *
     * @param jwtFilter the JWT filter used for authentication
     */
    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

/**
     * Configures the security filter chain.
     * <p>
     * This method:
     * <ul>
     *     <li>Disables CSRF protection</li>
     *     <li>Enables CORS</li>
     *     <li>Configures frame options for H2 console</li>
     *     <li>Defines role-based access to endpoints</li>
     *     <li>Sets stateless session policy</li>
     *     <li>Adds JWT filter to the security chain</li>
     * </ul>
     *
     * @param http the {@link HttpSecurity} configuration object
     * @return the configured {@link SecurityFilterChain}
     * @throws Exception if configuration fails
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> {})

            .headers(headers -> headers
                .frameOptions(frame -> frame.disable())
            )

            .authorizeHttpRequests(auth -> auth

                // PUBLIC
                .requestMatchers("/h2-console/**").permitAll()
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()

                // GET -> USER + ADMIN
                .requestMatchers(HttpMethod.GET, "/validate/**")
                    .hasAnyRole("ADMIN", "USER")

                // future POST/PUT/DELETE -> ADMIN ONLY
                .requestMatchers(HttpMethod.POST, "/validate/**")
                    .hasRole("ADMIN")

                .requestMatchers(HttpMethod.PUT, "/validate/**")
                    .hasRole("ADMIN")

                .requestMatchers(HttpMethod.DELETE, "/validate/**")
                    .hasRole("ADMIN")

                .anyRequest().authenticated()
            )

            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            );

        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // CORS CONFIG
    /**
     * Configures Cross-Origin Resource Sharing (CORS) settings.
     * <p>
     * This configuration allows:
     * <ul>
     *     <li>All origins (for development purposes)</li>
     *     <li>All HTTP methods</li>
     *     <li>All request headers</li>
     *     <li>Exposure of Authorization header</li>
     * </ul>
     *
     * @return the configured {@link CorsConfigurationSource}
     */

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration config = new CorsConfiguration();

        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*");
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");

        config.addExposedHeader("Authorization");

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);

        return source;
    }
}