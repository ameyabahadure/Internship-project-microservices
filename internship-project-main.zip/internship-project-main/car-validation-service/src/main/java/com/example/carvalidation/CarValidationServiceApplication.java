package com.example.carvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the Car Validation Service application.
 * <p>
 * This class bootstraps the Spring Boot application responsible for
 * validating car registration numbers used by other microservices.
 * </p>
 *
 * <p>
 * It uses:
 * <ul>
 *     <li>{@link SpringBootApplication} for enabling auto-configuration,
 *         component scanning, and Spring Boot features</li>
 * </ul>
 * </p>
 *
 * @author
 * @since 1.0
 */

@SpringBootApplication
public class CarValidationServiceApplication {

	/**
     * Main method invoked to start the Spring Boot application.
     *
     * @param args command-line arguments passed during application startup
     */

	public static void main(String[] args) {
		SpringApplication.run(CarValidationServiceApplication.class, args);
	}

}
