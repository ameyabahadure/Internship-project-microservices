package com.example.carvalidation.feign;
import feign.RequestInterceptor;

import feign.RequestTemplate;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;

/**
 * Feign client interceptor for propagating authentication headers
 * across microservice calls.
 * <p>
 * This interceptor extracts the Authorization header from the incoming
 * HTTP request and attaches it to outgoing Feign requests to ensure
 * secure communication between services.
 * </p>
 *
 * <p>
 * Commonly used in microservice architectures to forward JWT tokens
 * or other authentication credentials.
 * </p>
 *
 * @author
 * @since 1.0
 */
 
@Configuration
public class FeignClientInterceptor implements RequestInterceptor {

	/**
     * HTTP servlet request used to access incoming request headers.
     */
 
    @Autowired
    private HttpServletRequest request;

    /**
     * Applies the interceptor logic to outgoing Feign requests.
     * <p>
     * Retrieves the "Authorization" header from the incoming request
     * and adds it to the Feign request template if present.
     * </p>
     *
     * @param template the Feign request template to modify
     */
 
    @Override
    public void apply(RequestTemplate template) {
 
        String token = request.getHeader("Authorization");
 
        if (token != null) {

            template.header("Authorization", token);

        }

    }

}

 
