package com.example.carvalidation.model;
import java.time.LocalDateTime;

import org.antlr.v4.runtime.misc.NotNull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Entity class representing car validation records.
 * <p>
 * This class maps to the "car_validation_logs" table and stores
 * information about car registration validation results, including
 * whether the car is valid and the time of validation.
 * </p>
 *
 * <p>
 * It uses JPA annotations for ORM mapping between the application
 * and the database.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Entity
@Table(name = "car_validation_logs")
public class CarValidation {

	/**
     * Unique identifier for the validation record.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Car registration number being validated.
     */
    @NotNull
    @Column(name = "car_registration_number", nullable = false, length = 20)
    private String carRegistrationNumber;

    /**
     * Indicates whether the car registration number is valid.
     */
    @NotNull
    @Column(name = "is_valid", nullable = false)
    private Boolean isValid;

    /**
     * Timestamp when the validation was performed.
     */
    @NotNull
    @Column(name = "validation_timestamp", nullable = false)
    private LocalDateTime validationTimestamp;

    /**
     * Default constructor required by JPA.
     */
    public CarValidation() {}

    /**
     * Parameterized constructor to initialize validation fields.
     *
     * @param carRegistrationNumber the car registration number
     * @param isValid the validation result
     * @param validationTimestamp the timestamp of validation
     */
    public CarValidation(String carRegistrationNumber, Boolean isValid, LocalDateTime validationTimestamp) {
        this.carRegistrationNumber = carRegistrationNumber;
        this.isValid = isValid;
        this.validationTimestamp = validationTimestamp;
    }

    /**
     * Gets the ID of the validation record.
     *
     * @return the ID
     */
    public Long getId() {
        return id;
    }

    /**
     * Gets the car registration number.
     *
     * @return the car registration number
     */
    public String getCarRegistrationNumber() {
        return carRegistrationNumber;
    }

    /**
     * Sets the car registration number.
     *
     * @param carRegistrationNumber the registration number to set
     */
    public void setCarRegistrationNumber(String carRegistrationNumber) {
        this.carRegistrationNumber = carRegistrationNumber;
    }

    /**
     * Gets the validation result.
     *
     * @return {@code true} if valid, otherwise {@code false}
     */
    public Boolean getIsValid() {
        return isValid;
    }

    /**
     * Sets the validation result.
     *
     * @param isValid the validation result to set
     */
    public void setIsValid(Boolean isValid) {
        this.isValid = isValid;
    }

     /**
     * Gets the validation timestamp.
     *
     * @return the validation timestamp
     */
    public LocalDateTime getValidationTimestamp() {
        return validationTimestamp;
    }

    /**
     * Sets the validation timestamp.
     *
     * @param validationTimestamp the timestamp to set
     */
    public void setValidationTimestamp(LocalDateTime validationTimestamp) {
        this.validationTimestamp = validationTimestamp;
    }
}
