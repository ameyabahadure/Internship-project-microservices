package com.example.carvalidation.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.carvalidation.model.CarValidation;
import com.example.carvalidation.service.CarValidationService;

/**
 * REST controller for handling car validation operations.
 * <p>
 * This controller provides endpoints to:
 * <ul>
 *     <li>Validate whether a given car registration number is valid</li>
 *     <li>Retrieve all stored car validation records</li>
 * </ul>
 * </p>
 *
 * <p>
 * Base URL mapping: /validate
 * </p>
 *
 * @author
 * @since 1.0
 */

@RestController
@RequestMapping("/validate")
public class ValidationController {

	/**
     * Service layer dependency for handling car validation logic.
     */
    @Autowired
    private CarValidationService service;

    /**
     * Validates a given car registration number.
     * <p>
     * This endpoint checks whether the provided car number exists
     * and is considered valid in the system.
     * </p>
     *
     * @param carNumber the car registration number to validate
     * @return {@link ResponseEntity} containing {@code true} if valid,
     *         otherwise {@code false}
     */

    @GetMapping("/{carNumber}") //we only want to know if the carNumber is valid or not
    public ResponseEntity<Boolean> validate(@PathVariable String carNumber) {
    	
    	//we also can use .ok()method
        return ResponseEntity.ok(service.validateCarNumber(carNumber));
    }

    /**
     * Retrieves all car validation records.
     *
     * @return list of {@link CarValidation} objects
     */
    @GetMapping()
    public List<CarValidation> getAll(){
    		return service.getAll();
    }
}
