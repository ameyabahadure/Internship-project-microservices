package com.example.carvalidation.service;
import java.util.List;

import com.example.carvalidation.model.CarValidation;

/**
 * Service interface for handling car validation operations.
 * <p>
 * This interface defines methods for validating car registration
 * numbers and retrieving stored validation records.
 * </p>
 *
 * <p>
 * Implementations of this interface are responsible for applying
 * validation logic and interacting with persistence layers.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface CarValidationService {

	/**
     * Validates a given car registration number.
     *
     * @param carNumber the car registration number to validate
     * @return {@code true} if the car number is valid, otherwise {@code false}
     */
    boolean validateCarNumber(String carNumber);
    

    /**
     * Retrieves all car validation records.
     *
     * @return a list of {@link CarValidation} objects
     */

    public List<CarValidation> getAll() ;
}

