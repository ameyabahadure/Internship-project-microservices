package com.example.carvalidation.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.carvalidation.repo.CarValidationRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource("classpath:application-test.properties")
class ValidationIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private CarValidationRepository repo;

    // ✅ validate endpoint

    @Test
    void testValidateIntegration() throws Exception {

        mockMvc.perform(get("/validate/TN01AB1234"))
                .andExpect(status().isOk());

        assertFalse(repo.findAll().isEmpty()); 
    }

    @Test
    void testGetAllIntegration() throws Exception {

        // first create entry
        mockMvc.perform(get("/validate/TN01AB1234"));

        mockMvc.perform(get("/validate"))
                .andExpect(status().isOk());
    }
}
