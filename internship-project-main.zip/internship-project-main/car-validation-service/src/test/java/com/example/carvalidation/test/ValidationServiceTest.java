package com.example.carvalidation.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import com.example.carvalidation.model.CarValidation;
import com.example.carvalidation.repo.CarValidationRepository;
import com.example.carvalidation.service.ValidationServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidationServiceTest {

    @Mock
    private CarValidationRepository repo;

    @InjectMocks
    private ValidationServiceImpl service;

    // ✅ validateCarNumber()

    @Test
    void testValidateValidNumber() {

        boolean result = service.validateCarNumber("TN01AB1234");

        assertTrue(result);
    }

    @Test
    void testValidateInvalidNumber() {

        boolean result = service.validateCarNumber("123");

        assertFalse(result);
    }

    // ✅ getAll()

    @Test
    void testGetAllSuccess() {

        Mockito.when(repo.findAll()).thenReturn(List.of(new CarValidation()));

        assertFalse(service.getAll().isEmpty());
    }

    @Test
    void testGetAllEmpty() {

        Mockito.when(repo.findAll()).thenReturn(List.of());

        assertTrue(service.getAll().isEmpty());
    }
}