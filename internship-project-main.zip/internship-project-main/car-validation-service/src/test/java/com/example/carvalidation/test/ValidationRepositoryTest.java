package com.example.carvalidation.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.List;

import com.example.carvalidation.model.CarValidation;
import com.example.carvalidation.repo.CarValidationRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

@DataJpaTest
class ValidationRepositoryTest {

    @Autowired
    private CarValidationRepository repo;

    @Test
    void testSaveAndFind() {

        CarValidation log = new CarValidation();
        log.setCarRegistrationNumber("TN01AB1234");
        log.setIsValid(true);
        log.setValidationTimestamp(LocalDateTime.now());

        repo.save(log);

        List<CarValidation> list = repo.findAll();

        assertEquals(1, list.size());
    }

    @Test
    void testEmpty() {

        assertTrue(repo.findAll().isEmpty());
    }
}