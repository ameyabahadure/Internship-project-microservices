package com.example.carvalidation.test;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import com.example.carvalidation.model.CarValidation;
import com.example.carvalidation.service.CarValidationService;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class ValidationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CarValidationService service;

    // ✅ validate()

    @Test
    void testValidateTrue() throws Exception {

        when(service.validateCarNumber("TN01AB1234")).thenReturn(true);

        mockMvc.perform(get("/validate/TN01AB1234"))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

    @Test
    void testValidateFalse() throws Exception {

        when(service.validateCarNumber("INVALID")).thenReturn(false);

        mockMvc.perform(get("/validate/INVALID"))
                .andExpect(status().isOk())
                .andExpect(content().string("false"));
    }

    // ✅ getAll()

    @Test
    void testGetAllSuccess() throws Exception {

        when(service.getAll()).thenReturn(List.of(new CarValidation()));

        mockMvc.perform(get("/validate"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAllEmpty() throws Exception {

        when(service.getAll()).thenReturn(List.of());

        mockMvc.perform(get("/validate"))
                .andExpect(status().isOk());
    }
}