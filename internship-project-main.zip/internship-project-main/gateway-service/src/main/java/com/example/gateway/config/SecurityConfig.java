package com.example.gateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod; // ✅ CRITICAL IMPORT
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.example.gateway.service.CustomUserDetailsService;
import com.example.gateway.filter.JwtAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtAuthenticationFilter jwtFilter;
    
    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
        		.cors(cors->{})
            .authorizeHttpRequests(auth -> auth

.requestMatchers(
        "/auth/**",
        "/swagger-ui/**",
        "/v3/api-docs/**",
        "/swagger-ui.html",
        "/webjars/**",
        "/carservice/v3/api-docs",
        "/audit/v3/api-docs",
        "/validate/v3/api-docs",
        "/users/v3/api-docs"
    ).permitAll()

                // 1. Let public authentication pass
//                .requestMatchers("/auth/**", "/swagger-ui/**", "/v3/api-docs/**",
//                		 
//        				"/carservice/v3/api-docs", "/audit/v3/api-docs", "/validate/v3/api-docs", "/users/v3/api-docs" , 
//         
//        				"/carservice/swagger-ui/**", "/audit/swagger-ui/**", "/validate/swagger-ui/**" , "/users/swagger-ui/").permitAll()
                
                // 2.GET Requests: Accessible by BOTH ADMIN and USER
                .requestMatchers(HttpMethod.GET, "/users/**", "/carservice/**", "/audit/**", "/validate/**")
                    .hasAnyRole("ADMIN", "USER", "WORKER")
                
                // 3. All Modifying Requests (POST, PUT, DELETE): Restricted strictly to ADMIN
                .requestMatchers(HttpMethod.POST, "/users/**", "/carservice/**", "/audit/**", "/validate/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/users/**", "/carservice/**", "/audit/**", "/validate/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/users/**", "/carservice/**", "/audit/**", "/validate/**").hasRole("ADMIN")
                
                // 4. Fallback security constraint
                .anyRequest().authenticated()
            )
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder = http
                .getSharedObject(AuthenticationManagerBuilder.class);

        authenticationManagerBuilder.userDetailsService(userDetailsService)
                                    .passwordEncoder(passwordEncoder());

        return authenticationManagerBuilder.build();
    }
    @Bean
	public CorsConfigurationSource corsConfigurationSource() {
 
		CorsConfiguration config = new CorsConfiguration();
 
		config.setAllowCredentials(true);
 
		config.addAllowedOriginPattern("*"); // allow all origins (for dev)
 
		config.addAllowedHeader("*"); // allow Authorization header
		config.addAllowedMethod("*"); // GET, POST, PUT, DELETE
 
		config.addExposedHeader("Authorization");
 
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);
 
		return source;
	}
}