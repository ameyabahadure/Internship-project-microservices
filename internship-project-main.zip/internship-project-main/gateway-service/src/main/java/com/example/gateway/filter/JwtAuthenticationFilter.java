package com.example.gateway.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
 
import com.example.gateway.service.CustomUserDetailsService;
import com.example.gateway.service.JwtService;
 
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	@Autowired
	private JwtService jwtService;
 
	@Autowired
	private CustomUserDetailsService userDetailsService;
	
	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) {
	    String path = request.getRequestURI();
	 
	    return path.startsWith("/h2-console")
	        || path.startsWith("/swagger-ui")
	        || path.startsWith("/v3/api-docs")
	        || path.contains("/v3/api-docs")   // VERY IMPORTANT
	        || path.contains("/swagger-ui")
	        || path.startsWith("/auth");  // for routed services
	
	}
 
	@Override
	protected void doFilterInternal(HttpServletRequest request,
	        HttpServletResponse response,
	        FilterChain chain) throws ServletException, IOException {
 
	    final String authHeader = request.getHeader("Authorization");
 
	    String username = null;
	    String jwt = null;
 
	    try {
	        if (authHeader != null && authHeader.startsWith("Bearer ")) {
	            jwt = authHeader.substring(7);
	            username = jwtService.extractUsername(jwt);
	        }
 
	        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
	            UserDetails userDetails = userDetailsService.loadUserByUsername(username);
 
	            if (jwtService.validateToken(jwt, userDetails)) {
	                // FIXED: Extract clean role string from token claims
	                String rawRoles = jwtService.extractRole(jwt); 
	                
	                // Convert comma-separated roles back to Spring GrantedAuthorities
	                List<SimpleGrantedAuthority> authorities = Arrays.stream(rawRoles.split(","))
	                        .map(SimpleGrantedAuthority::new)
	                        .collect(Collectors.toList());

	                UsernamePasswordAuthenticationToken authToken =
	                        new UsernamePasswordAuthenticationToken(
	                                userDetails,
	                                null,
	                                authorities // Explicitly map authorities to grant access rights
	                        );
 
	                SecurityContextHolder.getContext().setAuthentication(authToken);
	            }
	        }
	        chain.doFilter(request, response);
 
	    } catch (Exception ex) {
	        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
	        response.setContentType("application/json");
	        response.getWriter().write(
	                "{ \"status\": 401, \"error\": \"Invalid or expired JWT token\" }"
	        );
	    }
	}
}