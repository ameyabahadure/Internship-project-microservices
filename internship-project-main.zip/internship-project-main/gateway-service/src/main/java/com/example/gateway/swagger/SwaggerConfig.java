package com.example.gateway.swagger;

import org.springframework.context.annotation.Bean;


import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
 
public class SwaggerConfig {
	
	@Bean
	public OpenAPI customOpenAPI() {
	    return new OpenAPI()
	        .info(new Info()
	            .title("Gateway API")
	            .version("1.0")
	            .description("Login first → get JWT → use Authorize button")
	        )
	        .addSecurityItem(new SecurityRequirement().addList("bearerAuth"))
	        .components(new Components()
	            .addSecuritySchemes("bearerAuth",
	                new SecurityScheme()
	                    .name("Authorization")
	                    .type(SecurityScheme.Type.HTTP)
	                    .scheme("bearer")
	                    .bearerFormat("JWT")
	            )
	        );
	}
 
}
