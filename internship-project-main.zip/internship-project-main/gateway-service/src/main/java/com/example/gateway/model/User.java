package com.example.gateway.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "user_profiles")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private String role;
    
    @Column(nullable=false)
    private String password;
    
    @Column(nullable = false)
    private LocalDateTime createdAt;

    public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	@PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
    
    public User() {}
    
	

//	public UserProfile(Long id, String username, String role, String password ) {
//		super();
//		this.id = id;
//		this.username = username;
//		this.role = role;
//		this.password = password;
////		this.createdAt = createdAt;
//	}

	public User(Long id, String username, String role, String password, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.username = username;
		this.role = role;
		this.password = password;
		this.createdAt = createdAt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
	


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



	@Override
	public String toString() {
		return "UserProfile [id=" + id + ", username=" + username + ", role=" + role + ", password=" + password
				+ ", createdAt=" + createdAt + "]";
	}

    
}
