package com.example.user;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.user.repo.UserProfileRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource("classpath:application-test.properties")
class UserProfileIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserProfileRepository repo;

    @Test
    void testCreateAndGet() throws Exception {

        String json = """
        {
          "username":"test",
          "password":"123",
          "role":"USER"
        }
        """;

        mockMvc.perform(post("/users/save")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isCreated());

        assertFalse(repo.findAll().isEmpty());

        mockMvc.perform(get("/users/test"))
                .andExpect(status().isOk());
    }

    @Test
    void testDeleteIntegration() throws Exception {

        String json = """
        {
          "username":"test",
          "password":"123",
          "role":"USER"
        }
        """;

        mockMvc.perform(post("/users/save")
                .contentType("application/json")
                .content(json));

        Long id = repo.findAll().get(0).getId();

        mockMvc.perform(delete("/users/" + id))
                .andExpect(status().isOk());
    }
}
