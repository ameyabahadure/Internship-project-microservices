package com.example.user;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import com.example.user.exception.ResourceNotFoundException;
import com.example.user.model.UserProfile;
import com.example.user.repo.UserProfileRepository;
import com.example.user.service.UserProfileServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserProfileServiceTest {

    @Mock
    private UserProfileRepository repo;

    @InjectMocks
    private UserProfileServiceImpl service;

    // ✅ CREATE

    @Test
    void testCreate() {

        UserProfile user = new UserProfile();

        Mockito.when(repo.save(user)).thenReturn(user);

        assertNotNull(service.create(user));
    }

    @Test
    void testCreateNull() {

        assertThrows(Exception.class,
                () -> service.create(null));
    }

    // ✅ GET BY USERNAME

    @Test
    void testGetByUsernameSuccess() {

        UserProfile user = new UserProfile();
        user.setUsername("test");

        Mockito.when(repo.findByUsername("test"))
                .thenReturn(Optional.of(user));

        assertEquals("test", service.getByUsername("test").getUsername());
    }

    @Test
    void testGetByUsernameFail() {

        Mockito.when(repo.findByUsername("x"))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.getByUsername("x"));
    }

    // ✅ DELETE

    @Test
    void testDeleteSuccess() {

        UserProfile user = new UserProfile();
        user.setId(1L);

        Mockito.when(repo.findById(1L))
                .thenReturn(Optional.of(user));

        String msg = service.deleteUserById(1L);

        assertTrue(msg.contains("successfully"));
    }

    @Test
    void testDeleteFail() {

        Mockito.when(repo.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.deleteUserById(1L));
    }
}