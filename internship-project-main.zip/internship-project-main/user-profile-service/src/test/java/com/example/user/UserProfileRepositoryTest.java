package com.example.user;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import com.example.user.model.UserProfile;
import com.example.user.repo.UserProfileRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

@DataJpaTest
class UserProfileRepositoryTest {

    @Autowired
    private UserProfileRepository repo;

    @Test
    void testSaveAndFind() {

        UserProfile user = new UserProfile();
        user.setUsername("test");
        user.setPassword("123");
        user.setRole("USER");

        repo.save(user);

        List<UserProfile> list = repo.findAll();

        assertEquals(1, list.size());
    }

    @Test
    void testEmpty() {

        assertTrue(repo.findAll().isEmpty());
    }
}