package com.example.user;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import com.example.user.model.UserProfile;
import com.example.user.service.UserProfileService;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

@SpringBootTest
@AutoConfigureMockMvc
class UserProfileControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private UserProfileService service;

    // ✅ CREATE (2 cases)

    @Test
    void testCreateSuccess() throws Exception {

        UserProfile user = new UserProfile();
        user.setId(1L);

        when(service.create(Mockito.any())).thenReturn(user);

        mockMvc.perform(post("/users/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"a\",\"password\":\"p\",\"role\":\"USER\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(1)));
    }

    @Test
    void testCreateFail() throws Exception {

        mockMvc.perform(post("/users/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest());
    }

    // ✅ GET ALL

    @Test
    void testGetAll() throws Exception {

        when(service.getAll()).thenReturn(List.of(new UserProfile()));

        mockMvc.perform(get("/users"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAllEmpty() throws Exception {

        when(service.getAll()).thenReturn(List.of());

        mockMvc.perform(get("/users"))
                .andExpect(status().isOk());
    }

    // ✅ GET BY USERNAME

    @Test
    void testGetUserSuccess() throws Exception {

        UserProfile user = new UserProfile();
        user.setUsername("test");

        when(service.getByUsername("test")).thenReturn(user);

        mockMvc.perform(get("/users/test"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", is("test")));
    }

    @Test
    void testGetUserFail() throws Exception {

        when(service.getByUsername("test"))
                .thenThrow(new RuntimeException());

        mockMvc.perform(get("/users/test"))
                .andExpect(status().isInternalServerError());
    }

}