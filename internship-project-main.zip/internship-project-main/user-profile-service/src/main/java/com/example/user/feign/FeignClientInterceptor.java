package com.example.user.feign;
import feign.RequestInterceptor;

import feign.RequestTemplate;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;

/**
 * Feign client interceptor for propagating Authorization headers
 * between microservices.
 * <p>
 * This interceptor ensures that the incoming HTTP request's
 * Authorization header (typically containing a JWT token)
 * is forwarded to all outgoing Feign requests.
 * </p>
 *
 * <p>
 * This is essential in microservices architectures where
 * authentication context must be preserved across service calls.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Configuration
public class FeignClientInterceptor implements RequestInterceptor {

/**
     * HTTP servlet request used to access incoming request headers.
     */
 
    @Autowired
    private HttpServletRequest request;

/**
     * Applies the interceptor logic to outgoing Feign requests.
     * <p>
     * Extracts the Authorization header from the incoming request
     * and attaches it to the Feign request template if present.
     * </p>
     *
     * @param template the Feign request template to modify
     */
 
    @Override
    public void apply(RequestTemplate template) {
 
        String token = request.getHeader("Authorization");
 
        if (token != null) {

            template.header("Authorization", token);

        }

    }

}

 
