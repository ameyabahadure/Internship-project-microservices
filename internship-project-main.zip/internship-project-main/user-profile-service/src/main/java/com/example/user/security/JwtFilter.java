package com.example.user.security;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JWT filter for handling authentication and authorization
 * in the User Profile Service.
 * <p>
 * This filter intercepts incoming HTTP requests and performs:
 * <ul>
 *     <li>Extraction of JWT token from Authorization header</li>
 *     <li>Validation of token signature and expiration</li>
 *     <li>Extraction of username and user roles</li>
 *     <li>Creation of Spring Security authentication context</li>
 * </ul>
 * </p>
 *
 * <p>
 * Certain endpoints such as H2 console and Swagger UI are excluded
 * from filtering.
 * </p>
 *
 * <p>
 * Ensures role-based access control (RBAC) by mapping roles from JWT
 * into {@link SimpleGrantedAuthority}.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Component
public class JwtFilter extends OncePerRequestFilter {

/**
     * Secret key used for signing and validating JWT tokens.
     */

    private final String SECRET = "X9aB7cQmP4tR2vL8wZ6yN0kD3fH5jG1uE7oS4nM2bV9rT8qC5xJ";

/**
     * Determines whether this filter should be applied to the request.
     * <p>
     * Skips filtering for H2 console and Swagger endpoints.
     * </p>
     *
     * @param request the HTTP request
     * @return {@code true} if the filter should not be applied, otherwise {@code false}
     */

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();

        return path.startsWith("/h2-console")
                || path.startsWith("/swagger-ui")
                || path.startsWith("/v3/api-docs")
                || path.contains("/v3/api-docs")
                || path.contains("/swagger-ui");
    }


/**
     * Core filter logic for validating JWT tokens and setting authentication.
     * <p>
     * This method:
     * <ul>
     *     <li>Validates presence of Authorization header</li>
     *     <li>Parses and validates JWT token</li>
     *     <li>Checks token expiration</li>
     *     <li>Extracts username and roles</li>
     *     <li>Builds authentication object and sets it in SecurityContext</li>
     * </ul>
     * </p>
     *
     * @param request the HTTP request
     * @param response the HTTP response
     * @param filterChain the filter chain
     * @throws ServletException if servlet error occurs
     * @throws IOException if I/O error occurs
     */

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("JWT token is missing");
            return;
        }

        String token = authHeader.substring(7);

        try {
            SecretKey key = Keys.hmacShaKeyFor(SECRET.getBytes());

            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            if (claims.getExpiration().before(new Date())) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("JWT expired");
                return;
            }

            String username = claims.getSubject();

            // ROLE EXTRACTION
            String roles = claims.get("role", String.class);

            List<SimpleGrantedAuthority> authorities =
                    Arrays.stream(roles.split(","))
                            .map(String::trim)
                            .map(role -> {
                                if (!role.startsWith("ROLE_")) {
                                    return "ROLE_" + role;
                                }
                                return role;
                            })
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());

            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(
                            username,
                            null,
                            authorities
                    );

            SecurityContextHolder.getContext().setAuthentication(authentication);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\": \"Invalid or expired JWT token\"}");
            return;
        }

        filterChain.doFilter(request, response);
    }
}