package com.example.user.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.UserProfile;
import com.example.user.service.UserProfileService;

/**
 * REST controller for handling user profile operations.
 * <p>
 * This controller provides endpoints to perform CRUD operations
 * on {@link UserProfile} entities.
 * </p>
 *
 * <p>
 * Base URL mapping: /users
 * </p>
 *
 * @author
 * @since 1.0
 */

@RestController
@RequestMapping("/users")
public class UserProfileController {

	/**
     * Service layer dependency for managing user profiles.
     */
    @Autowired
    private UserProfileService service;

/**
     * Creates a new user profile.
     * <p>
     * Validates that required fields (username, role, password) are present
     * before delegating to the service layer.
     * </p>
     *
     * @param user the {@link UserProfile} object containing user details
     * @return a {@link ResponseEntity} with created user or error message
     */

    @PostMapping("/save")
    public ResponseEntity<?> create(@RequestBody UserProfile user) {

    if (user.getUsername() == null ||
        user.getRole() == null ||
        user.getPassword() == null) {

        return ResponseEntity.badRequest()
                .body("Missing required fields");
    }

    return new ResponseEntity<>(
            service.create(user),
            HttpStatus.CREATED
    );
}

/**
     * Retrieves all user profiles.
     *
     * @return a list of {@link UserProfile} objects
     */
    
    @GetMapping()
    public List<UserProfile> getAll(){
    		return service.getAll();
    } 

/**
     * Retrieves a user profile by username.
     *
     * @param username the username of the user
     * @return the corresponding {@link UserProfile}
     */
    
    @GetMapping("/{username}")
    public UserProfile getUser(
            @PathVariable String username) {

        return service.getByUsername(username);
        
    }

/**
     * Updates an existing user profile by ID.
     *
     * @param id the unique identifier of the user
     * @param user the updated {@link UserProfile} object
     * @return the updated {@link UserProfile}
     */
    
    @PutMapping("/{id}")
    	public UserProfile updateUser(@PathVariable Long id ,  @RequestBody UserProfile user) {
    		return service.updateById(id, user);
    }

/**
     * Deletes a user profile by ID.
     *
     * @param id the unique identifier of the user to be deleted
     */
    
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
    		service.deleteUserById(id);
    }
    
}

