package com.example.user.repo;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.user.model.UserProfile;

/**
 * Repository interface for performing CRUD operations on
 * {@link UserProfile} entities.
 * <p>
 * This interface extends {@link JpaRepository} to provide built-in
 * methods for database operations such as save, update, delete,
 * and retrieval of user profile records.
 * </p>
 *
 * <p>
 * It also defines custom query methods for accessing user data
 * based on specific fields.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {

/**
     * Retrieves a user profile by username.
     *
     * @param username the username of the user
     * @return an {@link Optional} containing the {@link UserProfile} if found,
     *         otherwise empty
     */

	Optional<UserProfile> findByUsername(String username);
	
	
}
