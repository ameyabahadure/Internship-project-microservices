package com.example.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

//import com.example.carservice.exception.ResourceNotFoundException;
//import com.example.carservice.model.CarService;
import com.example.user.exception.*;

import com.example.user.model.UserProfile;
import com.example.user.repo.UserProfileRepository;
import com.example.user.service.UserProfileService;

@Service
public class UserProfileServiceImpl implements UserProfileService {

    @Autowired
    private UserProfileRepository repository;
    

    @Override
    public UserProfile create(UserProfile user) {

    		if (user == null) {
    			throw new IllegalArgumentException("User cannot be null");
    		}

    		return repository.save(user);
    }

    

    @Override
    public UserProfile getByUsername(String username) {
        
//    		//throw user not found exception 
	    	 return repository.findByUsername(username)
	    	            .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

	@Override
	public List<UserProfile> getAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}


	@Override
	public String deleteUserById(Long id) {
		//check if user exist		
		UserProfile exists = repository.findById(id)
	            .orElseThrow(() -> new ResourceNotFoundException("User profile record not found with id: " + id));
	    
	    repository.deleteById(id);
	    
	    return "User with id: " + id + " successfully deleted";
	}

	@Override
	public UserProfile updateById(Long id, UserProfile user) {
		
		if(id == null || id<=0) {
			throw new ResourceNotFoundException("user does not exist");
		}
		
		UserProfile exists = repository.getById(id);
		
		//update the data 
		exists.setRole(user.getRole());
		exists.setUsername(user.getUsername());
		
		return repository.save(exists);
	}
}
