package com.example.user.exception;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.user.dto.GenericResponse;

/**
 * Global exception handler for managing application-wide exceptions.
 * <p>
 * This class uses {@link RestControllerAdvice} to intercept exceptions
 * thrown by controllers and return appropriate HTTP responses.
 * </p>
 *
 * <p>
 * It provides centralized error handling to ensure consistent
 * response formats across the application.
 * </p>
 *
 * @author
 * @since 1.0
 */

@RestControllerAdvice
public class GlobalExceptionHandler {

/**
     * Handles all runtime exceptions.
     *
     * @param ex the {@link RuntimeException} thrown during request processing
     * @return a {@link ResponseEntity} with HTTP status 500 (Internal Server Error)
     *         containing the exception message
     */


@ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleRuntime(RuntimeException ex) {

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ex.getMessage());
    }

/**
     * Handles resource not found exceptions.
     *
     * @param ex the {@link ResourceNotFoundException} thrown when a resource is not found
     * @return a {@link ResponseEntity} with HTTP status 404 (Not Found)
     *         containing the exception message
     */

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<String> handleNotFound(ResourceNotFoundException ex) {

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(ex.getMessage());
    }

}
