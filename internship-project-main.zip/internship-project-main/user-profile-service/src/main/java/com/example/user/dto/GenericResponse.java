package com.example.user.dto;
import java.time.LocalDateTime;

/**
 * Generic response wrapper class used for standardizing API responses.
 * <p>
 * This class encapsulates a message, optional data payload, and a timestamp
 * indicating when the response was created.
 * </p>
 *
 * <p>
 * It supports both responses with and without data by providing
 * overloaded constructors.
 * </p>
 *
 * @param <T> the type of the response data payload
 *
 * @author
 * @since 1.0
 */

public class GenericResponse<T> {
	
/**
     * Response message describing the outcome.
     */
    private final String message;

    /**
     * Optional response data payload.
     */
    private final T data;

    /**
     * Timestamp indicating when the response was generated.
     */
    private final LocalDateTime timestamp;

    /**
     * Constructs a response with only a message.
     *
     * @param message the response message
     */

    public GenericResponse(String message) {
        this.message = message;
        this.data = null;
        this.timestamp = LocalDateTime.now();
    }

/**
     * Constructs a response with both message and data.
     *
     * @param message the response message
     * @param data the response data payload
     */

    public GenericResponse(String message, T data) {
        this.message = message;
        this.data = data;
        this.timestamp = LocalDateTime.now();
    }
}
