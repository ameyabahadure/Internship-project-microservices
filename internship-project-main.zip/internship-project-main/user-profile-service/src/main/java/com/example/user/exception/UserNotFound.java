package com.example.user.exception;

/**
 * Custom exception thrown when a user resource is not found.
 * <p>
 * This exception extends {@link RuntimeException} and is typically used
 * to indicate that a user with a specified identifier (such as ID or username)
 * does not exist in the system.
 * </p>
 *
 * <p>
 * It can be handled globally using a centralized exception handler
 * (e.g., {@link GlobalExceptionHandler}) to return an appropriate
 * HTTP response.
 * </p>
 *
 * @author
 * @since 1.0
 */

public class UserNotFound extends RuntimeException {

/**
     * Constructs a new {@code UserNotFound} exception with the specified message.
     *
     * @param message the detail message explaining why the exception occurred
     */

    public UserNotFound(String message) {
        super(message);
    }
}
