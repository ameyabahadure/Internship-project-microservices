package com.example.user.service;
import java.util.List;

import com.example.user.model.UserProfile;

/**
 * Service interface for managing user profile operations.
 * <p>
 * This interface defines the contract for performing CRUD operations
 * on {@link UserProfile} entities, including creation, retrieval,
 * update, and deletion.
 * </p>
 *
 * <p>
 * Implementations of this interface should contain business logic,
 * validations, and interactions with the persistence layer.
 * </p>
 *
 * @author
 * @since 1.0
 */

public interface UserProfileService {

/**
     * Creates a new user profile.
     *
     * @param user the {@link UserProfile} object containing user details
     * @return the created {@link UserProfile}
     */

    UserProfile create(UserProfile user);

/**
     * Retrieves a user profile by username.
     *
     * @param username the username of the user
     * @return the corresponding {@link UserProfile}
     */

    UserProfile getByUsername(String username);

/**
     * Retrieves all user profiles.
     *
     * @return a list of {@link UserProfile} objects
     */

    List<UserProfile> getAll();

/**
     * Deletes a user profile by its unique identifier.
     *
     * @param id the ID of the user to be deleted
     * @return a confirmation message indicating result of deletion
     */

    String deleteUserById(Long id);

/**
     * Updates an existing user profile.
     *
     * @param id the unique identifier of the user
     * @param user the updated {@link UserProfile} object
     * @return the updated {@link UserProfile}
     */

    UserProfile updateById(Long id , UserProfile user);
}