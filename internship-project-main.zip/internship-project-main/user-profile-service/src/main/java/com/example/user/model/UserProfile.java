package com.example.user.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

/**
 * Entity class representing a user profile.
 * <p>
 * This class maps to the "user_profiles" table and stores user-related
 * information such as username, role, password, and creation timestamp.
 * </p>
 *
 * <p>
 * It uses JPA annotations for object-relational mapping and lifecycle
 * callbacks to automatically populate certain fields.
 * </p>
 *
 * @author
 * @since 1.0
 */

@Entity
@Table(name = "user_profiles")
public class UserProfile {

    /**
     * Unique identifier for the user profile.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Username of the user.
     */
    @Column(nullable = false)
    private String username;

    /**
     * Role assigned to the user (e.g., ADMIN, USER).
     */
    @Column(nullable = false)
    private String role;
    
    /**
     * Password of the user.
     */
    @Column(nullable=false)
    private String password;
    
    /**
     * Timestamp indicating when the user profile was created.
     */
    @Column(nullable = false)
    private LocalDateTime createdAt;

    /**
     * Gets the creation timestamp.
     *
     * @return the creation timestamp
     */
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the creation timestamp.
     *
     * @param createdAt the timestamp to set
     */
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Lifecycle callback method triggered before persisting the entity.
     * <p>
     * Automatically sets the creation timestamp.
     * </p>
     */
    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
    
    /**
     * Default constructor required by JPA.
     */
    public UserProfile() {
    	
    }
    

    /**
     * Parameterized constructor to initialize user profile fields.
     *
     * @param id the unique identifier
     * @param username the username
     * @param role the user role
     * @param password the user password
     * @param createdAt the creation timestamp
     */
    public UserProfile(Long id, String username, String role, String password, LocalDateTime createdAt) {
        super();
        this.id = id;
        this.username = username;
        this.role = role;
        this.password = password;
        this.createdAt = createdAt;
    }

    /**
     * Gets the user ID.
     *
     * @return the ID
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the user ID.
     *
     * @param id the ID to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the username.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username.
     *
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the user role.
     *
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the user role.
     *
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }
    
    
    /**
     * Gets the user password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the user password.
     *
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Returns a string representation of the user profile.
     *
     * @return string containing user profile details
     */
    @Override
    public String toString() {
        return "UserProfile [id=" + id + ", username=" + username + ", role=" + role + ", password=" + password
                + ", createdAt=" + createdAt + "]";
    }
}
