package com.example.user.swagger;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.security.SecurityScheme;
 
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for setting up OpenAPI (Swagger) documentation
 * for the User Profile Service.
 * <p>
 * This configuration defines API metadata and security settings to
 * enable interactive API documentation via Swagger UI.
 * </p>
 *
 * <p>
 * Features configured:
 * <ul>
 *     <li>API title and version information</li>
 *     <li>JWT Bearer token authentication</li>
 *     <li>Security requirement for protected endpoints</li>
 * </ul>
 * </p>
 *
 * <p>
 * This ensures that all secured endpoints require authorization
 * via a bearer token.
 * </p>
 *
 * @author
 * @since 1.0
 */
 
@Configuration
public class SwaggerConfig {

/**
     * Creates and configures the OpenAPI bean for Swagger UI.
     * <p>
     * This method:
     * <ul>
     *     <li>Adds a security requirement for bearer authentication</li>
     *     <li>Defines the JWT security scheme</li>
     *     <li>Sets API metadata such as title and version</li>
     * </ul>
     * </p>
     *
     * @return the configured {@link OpenAPI} instance
     */
 
	@Bean
	public OpenAPI customOpenAPI() {
		return new OpenAPI().addSecurityItem(new SecurityRequirement().addList("bearerAuth"))
				.components(new Components().addSecuritySchemes("bearerAuth",
						new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
				.info(new Info().title("User Profile API").version("1.0"));
	}
 
}
