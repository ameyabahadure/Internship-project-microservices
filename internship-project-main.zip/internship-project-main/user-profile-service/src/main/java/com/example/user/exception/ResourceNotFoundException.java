package com.example.user.exception;

/**
 * Custom exception thrown when a requested resource is not found.
 * <p>
 * This exception extends {@link RuntimeException} and is used to
 * indicate that a specific entity or resource could not be located
 * in the system.
 * </p>
 *
 * <p>
 * Typically used in service or repository layers to signal missing
 * data, which can be handled globally using exception handlers.
 * </p>
 *
 * @author
 * @since 1.0
 */

public class ResourceNotFoundException extends RuntimeException {

/**
     * Constructs a new {@code ResourceNotFoundException} with the specified detail message.
     *
     * @param message the detail message explaining the reason for the exception
     */

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
