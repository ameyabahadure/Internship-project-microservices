package com.example.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the User Profile Service application.
 * <p>
 * This class is responsible for bootstrapping the Spring Boot
 * application that manages user profile-related functionalities.
 * </p>
 *
 * <p>
 * It enables:
 * <ul>
 *     <li>Auto-configuration</li>
 *     <li>Component scanning</li>
 *     <li>Spring Boot application startup</li>
 * </ul>
 * using the {@link SpringBootApplication} annotation.
 * </p>
 *
 * @author
 * @since 1.0
 */
@SpringBootApplication
public class UserProfileServiceApplication {

    /**
     * Main method used to launch the User Profile Service.
     *
     * @param args command-line arguments passed during application startup
     */
    public static void main(String[] args) {
        SpringApplication.run(UserProfileServiceApplication.class, args);
    }

}